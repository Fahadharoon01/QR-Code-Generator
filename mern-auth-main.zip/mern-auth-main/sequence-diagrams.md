# 📐 CareerKonnekt - Complete Sequence Diagrams Specification

## 📚 Table of Contents
1. [Applicant Sequence Diagrams](#applicant-sequences)
2. [Company Sequence Diagrams](#company-sequences)
3. [Admin Sequence Diagrams](#admin-sequences)
4. [How to Read These Diagrams](#how-to-read)
5. [PlantUML Rendering Instructions](#rendering)

---

## 🎯 How to Read These Diagrams <a name="how-to-read"></a>

### Symbols & Notation:
- **Actor (stick figure):** User, Company, Admin
- **Participant (box):** System components (Frontend, Server-1, Server-2, Database, etc.)
- **Solid arrow (→):** Synchronous call (waits for response)
- **Dashed arrow (-->):** Return/Response
- **Activation bar (vertical rectangle):** Component is processing
- **X (cross):** Lifeline termination/end
- **alt/else:** Alternative flow (if-else condition)
- **opt:** Optional flow (may or may not execute)
- **loop:** Repeated flow
- **par:** Parallel execution

---

# 👤 APPLICANT SEQUENCE DIAGRAMS <a name="applicant-sequences"></a>

## SD1: User Registration & Email Verification

**Use Case:** UC1
**Actors:** Applicant, Frontend, Server-1, MongoDB, NodeMailer
**Purpose:** Register new applicant account with email verification

```plantuml
@startuml
actor Applicant
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB
participant "NodeMailer\n(Email Service)" as Email

title SD1: User Registration & Email Verification

Applicant -> Frontend: 1. Navigate to Signup Page
activate Frontend
Frontend -> Applicant: 2. Display Signup Form
deactivate Frontend

Applicant -> Frontend: 3. Fill Form & Select "Applicant" Role
activate Frontend
note right of Frontend
  Data: email, password, name,
  phone, location, current_role,
  skills, experience
end note

Frontend -> Frontend: 4. Validate Form Data (Client-side)

alt Validation Fails
    Frontend -> Applicant: 5a. Show Validation Errors
    deactivate Frontend
else Validation Success
    Frontend -> Server1: 5b. POST /api/applicants/register
    activate Server1
    note right of Server1
      Request Body: {
        email, password, name,
        phone_no, location,
        current_role, skills,
        experience
      }
    end note
    
    Server1 -> Server1: 6. Validate Data (Server-side)
    
    alt Email Already Exists
        Server1 -> DB: 7a. Check if Email Exists
        activate DB
        DB -> Server1: Email Found
        deactivate DB
        Server1 -> Frontend: Email Already Registered
        Frontend -> Applicant: Show Error Message
        deactivate Server1
        deactivate Frontend
    else Email Available
        Server1 -> Server1: 7b. Hash Password (bcrypt)
        
        Server1 -> DB: 8. Create User Record
        activate DB
        note right of DB
          Collection: users
          Data: email, hashed_password,
          role: "applicant",
          is_verified: false
        end note
        DB -> Server1: User Created (user_id)
        deactivate DB
        
        Server1 -> DB: 9. Create Applicant Record
        activate DB
        note right of DB
          Collection: applicants
          Data: user_id, name, email,
          phone_no, location,
          current_role, skills,
          experience
        end note
        DB -> Server1: Applicant Created
        deactivate DB
        
        Server1 -> Server1: 10. Generate OTP (6 digits)
        
        Server1 -> DB: 11. Save OTP to User Record
        activate DB
        note right of DB
          Update: verify_otp,
          verify_otp_expire_at
          (expires in 10 minutes)
        end note
        DB -> Server1: OTP Saved
        deactivate DB
        
        Server1 -> Email: 12. Send Verification Email
        activate Email
        note right of Email
          To: applicant.email
          Subject: "Verify Your Email"
          Body: OTP code
        end note
        
        alt Email Delivery Success
            Email -> Server1: Email Sent Successfully
            deactivate Email
            Server1 -> Frontend: 13a. Registration Success
            deactivate Server1
            Frontend -> Applicant: Show "Check Email for OTP"
            deactivate Frontend
            
            == Email Verification Flow ==
            
            Applicant -> Frontend: 14. Enter OTP Code
            activate Frontend
            Frontend -> Server1: POST /api/auth/verify-email
            activate Server1
            note right of Server1
              Request Body: {
                email,
                otp
              }
            end note
            
            Server1 -> DB: 15. Fetch User by Email
            activate DB
            DB -> Server1: User Data with verify_otp
            deactivate DB
            
            alt OTP Invalid or Expired
                Server1 -> Server1: 16a. Check OTP validity
                Server1 -> Frontend: OTP Invalid/Expired
                Frontend -> Applicant: Show Error & Resend Option
                deactivate Server1
                deactivate Frontend
            else OTP Valid
                Server1 -> DB: 16b. Update User
                activate DB
                note right of DB
                  Set: is_verified = true
                  Clear: verify_otp fields
                end note
                DB -> Server1: User Verified
                deactivate DB
                
                Server1 -> Frontend: Verification Success
                deactivate Server1
                Frontend -> Applicant: "Email Verified! Please Login"
                deactivate Frontend
                destroy Frontend
            end
            
        else Email Delivery Failed
            Email -> Server1: 13b. Email Sending Failed
            deactivate Email
            Server1 -> Frontend: Registration Success but Email Failed
            deactivate Server1
            Frontend -> Applicant: Account Created, Resend OTP
            deactivate Frontend
        end
    end
end

@enduml
```

**Key Points:**
- **Starts:** Applicant navigates to signup
- **Ends:** Email verified successfully (X on Frontend lifeline)
- **Alternative Flows:**
  - Email already exists
  - Validation failures
  - OTP invalid/expired
  - Email delivery failure

---

## SD2: User Login & Dashboard Access

**Use Case:** UC2
**Actors:** Applicant, Frontend, Server-1, MongoDB
**Purpose:** Authenticate user and provide access token

```plantuml
@startuml
actor Applicant
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB

title SD2: User Login & Dashboard Access

Applicant -> Frontend: 1. Navigate to Login Page
activate Frontend
Frontend -> Applicant: 2. Display Login Form
deactivate Frontend

Applicant -> Frontend: 3. Enter Email & Password
activate Frontend
Frontend -> Frontend: 4. Client-side Validation

alt Validation Fails
    Frontend -> Applicant: 5a. Show Validation Errors
    deactivate Frontend
else Validation Success
    Frontend -> Server1: 5b. POST /api/auth/login
    activate Server1
    note right of Server1
      Request Body: {
        email,
        password
      }
    end note
    
    Server1 -> DB: 6. Find User by Email
    activate DB
    DB -> Server1: User Data (or null)
    deactivate DB
    
    alt User Not Found
        Server1 -> Frontend: 7a. Invalid Credentials
        deactivate Server1
        Frontend -> Applicant: Show "Invalid Email or Password"
        deactivate Frontend
    else User Found
        Server1 -> Server1: 7b. Compare Password (bcrypt)
        
        alt Password Incorrect
            Server1 -> Frontend: 8a. Invalid Credentials
            deactivate Server1
            Frontend -> Applicant: Show "Invalid Email or Password"
            deactivate Frontend
        else Password Correct
            Server1 -> Server1: 8b. Check is_verified Status
            
            alt Email Not Verified
                Server1 -> Frontend: 9a. Email Not Verified
                deactivate Server1
                Frontend -> Applicant: "Please Verify Email First"
                deactivate Frontend
            else Email Verified
                Server1 -> Server1: 9b. Generate JWT Token
                note right of Server1
                  Token Payload: {
                    userId: user._id,
                    userRole: "applicant"
                  }
                  Expires: 7 days
                end note
                
                Server1 -> DB: 10. Get Applicant Profile
                activate DB
                DB -> Server1: Applicant Data
                deactivate DB
                
                Server1 -> Frontend: 11. Login Success
                deactivate Server1
                note right of Server1
                  Response: {
                    success: true,
                    token: "JWT_TOKEN",
                    user: { name, email, role },
                    applicant: { profile data }
                  }
                end note
                
                Frontend -> Frontend: 12. Store Token (localStorage)
                Frontend -> Frontend: 13. Store User Data
                
                Frontend -> Applicant: 14. Redirect to Dashboard
                deactivate Frontend
                destroy Frontend
                
                note right of Applicant
                  User successfully logged in
                  Can now access protected routes
                end note
            end
        end
    end
end

@enduml
```

**Key Points:**
- **Starts:** Applicant enters credentials
- **Ends:** Redirected to dashboard with token stored
- **Alternative Flows:**
  - User not found
  - Wrong password
  - Email not verified

---

## SD3: Profile Management with AI Sync

**Use Case:** UC4
**Actors:** Applicant, Frontend, Server-1, MongoDB, Server-2, Pinecone, OpenAI
**Purpose:** Create/update profile and sync to AI recommendation system

```plantuml
@startuml
actor Applicant
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB
participant "Server-2\n(FastAPI)" as Server2
participant "OpenAI\nEmbeddings API" as OpenAI
database "Pinecone\n(Vector DB)" as Pinecone

title SD3: Profile Management with AI Sync

Applicant -> Frontend: 1. Navigate to Profile Page
activate Frontend
Frontend -> Server1: 2. GET /api/applicant/profile
activate Server1
note right of Server1
  Headers: {
    Authorization: Bearer TOKEN
  }
end note

Server1 -> Server1: 3. Verify JWT Token

alt Token Invalid/Expired
    Server1 -> Frontend: 4a. Unauthorized (401)
    deactivate Server1
    Frontend -> Applicant: Redirect to Login
    deactivate Frontend
else Token Valid
    Server1 -> DB: 4b. Fetch Profile by userId
    activate DB
    DB -> Server1: Profile Data (or null)
    deactivate DB
    
    Server1 -> Frontend: 5. Profile Data Response
    deactivate Server1
    Frontend -> Applicant: Display Profile Form
    deactivate Frontend
end

Applicant -> Frontend: 6. Fill/Update Profile Information
activate Frontend
note right of Applicant
  Sections:
  - Personal Info
  - Professional Summary
  - Education
  - Experience
  - Projects
  - Skills
end note

Frontend -> Frontend: 7. Client-side Validation

Applicant -> Frontend: 8. Click "Save Profile"
Frontend -> Server1: 9. POST /api/applicant/profile
activate Server1
note right of Server1
  Request Body: {
    selectedTemplate,
    selectedAccentColor,
    personalInfo: {...},
    professionalSummary,
    education: [...],
    experience: [...],
    projects: [...],
    skills: [...]
  }
end note

Server1 -> Server1: 10. Validate All Fields

alt Validation Fails
    Server1 -> Frontend: 11a. Validation Error (400)
    deactivate Server1
    Frontend -> Applicant: Show Specific Errors
    deactivate Frontend
else Validation Success
    Server1 -> Server1: 11b. Check Profile Completion
    note right of Server1
      Complete if:
      - Personal info present
      - Has education OR experience
      - Has at least 1 skill
    end note
    
    Server1 -> DB: 12. Save/Update Profile
    activate DB
    note right of DB
      Collection: profiles
      Fields: all profile data
      + isProfileCompleted flag
    end note
    DB -> Server1: Profile Saved
    deactivate DB
    
    alt Profile NOT Complete
        Server1 -> Frontend: 13a. Profile Saved (Incomplete)
        deactivate Server1
        Frontend -> Applicant: "Profile Saved. Complete for Job Matching"
        deactivate Frontend
    else Profile Complete
        Server1 -> DB: 13b. Get Applicant Record
        activate DB
        DB -> Server1: Applicant Data
        deactivate DB
        
        == AI Service Integration ==
        
        Server1 -> Server2: 14. POST /api/profiles/ingest
        activate Server2
        note right of Server1
          Request Body: {
            applicant_id,
            name, email, phone_no,
            location, current_role,
            professional_summary,
            skills: [...],
            experience: years,
            education: [...],
            experiences: [...],
            projects: [...],
            desired_job_titles: [...]
          }
        end note
        
        Server2 -> Server2: 15. Prepare Text for Embedding
        note right of Server2
          Combined Text:
          "Current Role: ... | Professional Summary: ... |
          Skills: ... | Experience: ... | Education: ..."
        end note
        
        Server2 -> OpenAI: 16. Generate Embedding
        activate OpenAI
        note right of OpenAI
          Model: text-embedding-3-small
          Input: Combined profile text
        end note
        OpenAI -> Server2: Embedding Vector (1536 dimensions)
        deactivate OpenAI
        
        Server2 -> Pinecone: 17. Upsert Profile Vector
        activate Pinecone
        note right of Pinecone
          Namespace: "profiles"
          Vector ID: profile_{applicant_id}
          Vector: [0.234, -0.567, ...]
          Metadata: {
            applicant_id, name, email,
            location, current_role,
            skills, experience, etc.
          }
        end note
        Pinecone -> Server2: Vector Stored
        deactivate Pinecone
        
        Server2 -> Server1: 18. Ingestion Success
        deactivate Server2
        note right of Server2
          Response: {
            success: true,
            message: "Profile ingested",
            applicant_id,
            vector_id
          }
        end note
        
        opt AI Service Failed (Handled Gracefully)
            Server2 -> Server1: AI Service Error
            note right of Server1
              Profile still saved in MongoDB
              AI sync will be retried later
            end note
        end
        
        Server1 -> Frontend: 19. Profile Saved Successfully
        deactivate Server1
        Frontend -> Applicant: "Profile Saved & Synced to AI System!"
        deactivate Frontend
        destroy Frontend
    end
end

@enduml
```

**Key Points:**
- **Starts:** Applicant navigates to profile page
- **Ends:** Profile saved and synced to AI (X on Frontend)
- **Alternative Flows:**
  - Token invalid → Redirect to login
  - Validation errors → Show errors
  - Profile incomplete → Save but don't sync to AI
  - AI service fails → Profile still saved
- **Key Feature:** Microservices communication (Server-1 → Server-2)

---

## SD4: AI-Enhanced Profile Content (Gemini Integration)

**Use Case:** UC6
**Actors:** Applicant, Frontend, Server-1, Gemini AI
**Purpose:** Use AI to enhance profile content

```plantuml
@startuml
actor Applicant
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
participant "Gemini AI\n(Google)" as Gemini

title SD4: AI-Enhanced Profile Content

Applicant -> Frontend: 1. Writing Profile Content
activate Frontend
note right of Applicant
  User is on profile page
  Writing: Professional Summary,
  Education/Experience Description,
  or Project Description
end note

Applicant -> Frontend: 2. Click "AI Enhance" Button
Frontend -> Frontend: 3. Validate Content (not empty)

alt Content Empty
    Frontend -> Applicant: 4a. "Please add content first"
    deactivate Frontend
else Content Present
    Frontend -> Applicant: 4b. Show "Enhancing..." Loader
    
    Frontend -> Server1: 5. POST /api/applicant/profile/ai-enhance/{section}
    activate Server1
    note right of Server1
      Endpoints:
      - /ai-enhance/summary
      - /ai-enhance/education
      - /ai-enhance/experience
      - /ai-enhance/project
      
      Request Body: {
        text: "original content",
        context: {degree, institution} // if education
      }
    end note
    
    Server1 -> Server1: 6. Verify JWT Token
    
    alt Token Invalid
        Server1 -> Frontend: 7a. Unauthorized (401)
        deactivate Server1
        Frontend -> Applicant: Redirect to Login
        deactivate Frontend
    else Token Valid
        Server1 -> Server1: 7b. Validate Content Length
        
        alt Content Too Short (< 20 chars)
            Server1 -> Frontend: 8a. Content Too Short
            deactivate Server1
            Frontend -> Applicant: "Add more details to enhance"
            deactivate Frontend
        else Content Length OK
            Server1 -> Gemini: 8b. Generate Enhanced Content
            activate Gemini
            note right of Server1
              Prompt Examples:
              
              For Summary:
              "Enhance this professional summary
              to be more compelling and professional:
              {original_text}"
              
              For Experience:
              "Enhance this job experience description
              for {job_title} at {company}:
              {original_text}"
            end note
            
            alt Gemini API Error
                Gemini -> Server1: 9a. API Error / Rate Limit
                deactivate Gemini
                Server1 -> Frontend: AI Service Temporarily Unavailable
                deactivate Server1
                Frontend -> Applicant: "Try again later"
                deactivate Frontend
            else Gemini Success
                Gemini -> Server1: 9b. Enhanced Text
                deactivate Gemini
                note right of Gemini
                  Returns professional,
                  well-structured content
                  with better language
                end note
                
                Server1 -> Frontend: 10. Enhanced Content Response
                deactivate Server1
                note right of Server1
                  Response: {
                    success: true,
                    original: "...",
                    enhanced: "...",
                    section: "summary"
                  }
                end note
                
                Frontend -> Applicant: 11. Display Enhanced Content
                deactivate Frontend
                note right of Applicant
                  User can see:
                  - Original text
                  - Enhanced text (side-by-side)
                  - Options: Accept / Reject
                end note
                
                Applicant -> Frontend: 12. Accept or Reject Enhancement
                activate Frontend
                
                alt User Accepts
                    Frontend -> Frontend: 13a. Replace Content with Enhanced
                    Frontend -> Applicant: Content Updated
                    deactivate Frontend
                else User Rejects
                    Frontend -> Frontend: 13b. Keep Original Content
                    Frontend -> Applicant: Enhancement Discarded
                    deactivate Frontend
                    destroy Frontend
                end
            end
        end
    end
end

@enduml
```

**Key Points:**
- **Starts:** User clicks "AI Enhance" button
- **Ends:** User accepts/rejects enhanced content
- **Alternative Flows:**
  - Content empty or too short
  - Token invalid
  - Gemini API failure
  - User rejects enhancement

---

## SD5: Download CV/Resume with Template Selection

**Use Case:** UC8
**Actors:** Applicant, Frontend, Server-1, MongoDB, PDF Generator
**Purpose:** Generate and download professional CV

```plantuml
@startuml
actor Applicant
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB
participant "PDF Generator\n(PDFKit)" as PDF

title SD5: Download CV/Resume

Applicant -> Frontend: 1. Navigate to Profile Page
activate Frontend
Frontend -> Applicant: 2. Display Profile with CV Options
deactivate Frontend

Applicant -> Frontend: 3. Select CV Template
activate Frontend
note right of Applicant
  Templates Available:
  - Minimal
  - Modern
  - Classic
  - Professional
  - Creative
  - Minimal with Image
end note

Applicant -> Frontend: 4. Select Accent Color
note right of Applicant
  Colors: indigo, blue, green,
  red, purple, teal, orange
end note

Applicant -> Frontend: 5. Click "Download Resume"
Frontend -> Frontend: 6. Show Download Progress

Frontend -> Server1: 7. GET /api/applicant/profile/download-cv
activate Server1
note right of Server1
  Query Params: {
    template: "modern",
    color: "indigo"
  }
  Headers: {
    Authorization: Bearer TOKEN
  }
end note

Server1 -> Server1: 8. Verify JWT Token

alt Token Invalid
    Server1 -> Frontend: 9a. Unauthorized (401)
    deactivate Server1
    Frontend -> Applicant: Redirect to Login
    deactivate Frontend
else Token Valid
    Server1 -> DB: 9b. Fetch Profile by userId
    activate DB
    DB -> Server1: Profile Data
    deactivate DB
    
    Server1 -> Server1: 10. Check Profile Completion
    
    alt Profile Incomplete
        Server1 -> Frontend: 11a. Profile Not Complete
        deactivate Server1
        Frontend -> Applicant: "Complete profile to download CV"
        deactivate Frontend
    else Profile Complete
        Server1 -> PDF: 11b. Generate PDF with Template
        activate PDF
        note right of PDF
          Inputs:
          - Profile data (all sections)
          - Selected template
          - Accent color
          
          Process:
          - Load template layout
          - Apply color scheme
          - Format sections
          - Add styling
          - Generate PDF buffer
        end note
        
        PDF -> PDF: 12. Create PDF Document
        PDF -> PDF: 13. Add Personal Info Section
        PDF -> PDF: 14. Add Professional Summary
        PDF -> PDF: 15. Add Education Section
        PDF -> PDF: 16. Add Experience Section
        PDF -> PDF: 17. Add Projects Section
        PDF -> PDF: 18. Add Skills Section
        PDF -> PDF: 19. Apply Template Styling
        
        alt PDF Generation Error
            PDF -> Server1: 20a. Generation Failed
            deactivate PDF
            Server1 -> Frontend: PDF Generation Error
            deactivate Server1
            Frontend -> Applicant: "Failed to generate CV"
            deactivate Frontend
        else PDF Generated Successfully
            PDF -> Server1: 20b. PDF Buffer
            deactivate PDF
            note right of PDF
              Returns binary PDF data
              File size: ~100-500 KB
            end note
            
            Server1 -> Frontend: 21. PDF File Stream
            deactivate Server1
            note right of Server1
              Response Headers:
              Content-Type: application/pdf
              Content-Disposition: attachment;
                filename="CV_{name}.pdf"
            end note
            
            Frontend -> Frontend: 22. Trigger Browser Download
            Frontend -> Applicant: 23. CV Downloaded Successfully
            deactivate Frontend
            destroy Frontend
            
            note right of Applicant
              PDF saved to Downloads folder
              User can now share/print CV
            end note
        end
    end
end

@enduml
```

**Key Points:**
- **Starts:** User selects template and downloads
- **Ends:** PDF downloaded to user's device
- **Alternative Flows:**
  - Token invalid
  - Profile incomplete
  - PDF generation error

---

## SD6: Get AI-Powered Job Recommendations (Microservices Flow)

**Use Case:** UC9
**Actors:** Applicant, Frontend, Server-1, Server-2, Pinecone, OpenAI
**Purpose:** Get personalized job recommendations using AI

```plantuml
@startuml
actor Applicant
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
participant "Server-2\n(FastAPI)" as Server2
database "Pinecone\n(Vector DB)" as Pinecone

title SD6: AI-Powered Job Recommendations (Full Microservices Flow)

Applicant -> Frontend: 1. Navigate to Jobs/Recommendations Page
activate Frontend

Frontend -> Server1: 2. GET /api/applicant/recommendations
activate Server1
note right of Server1
  Query Params: {
    top_k: 10,
    location: "Remote",
    job_type: "Full-time"
  }
  Headers: {
    Authorization: Bearer TOKEN
  }
end note

Server1 -> Server1: 3. Verify JWT Token & Extract userId

alt Token Invalid
    Server1 -> Frontend: 4a. Unauthorized (401)
    deactivate Server1
    Frontend -> Applicant: Redirect to Login
    deactivate Frontend
else Token Valid
    Server1 -> Server1: 4b. Get applicant_id from userId
    
    == Server-1 to Server-2 Communication ==
    
    Server1 -> Server2: 5. POST /api/recommendations/
    activate Server2
    note right of Server1
      Request to AI Service:
      {
        applicant_id: "507f...",
        top_k: 10,
        filters: {
          location: "Remote",
          job_type: "Full-time"
        }
      }
    end note
    
    Server2 -> Pinecone: 6. Fetch Applicant Profile Vector
    activate Pinecone
    note right of Server2
      Query: {
        namespace: "profiles",
        id: "profile_507f..."
      }
    end note
    
    alt Profile Not Found in Pinecone
        Pinecone -> Server2: 7a. Profile Not Found (404)
        deactivate Pinecone
        Server2 -> Server1: Profile Not in AI System
        deactivate Server2
        Server1 -> Frontend: Need to Sync Profile First
        deactivate Server1
        Frontend -> Applicant: "Please update profile to get recommendations"
        deactivate Frontend
    else Profile Found
        Pinecone -> Server2: 7b. Profile Vector + Metadata
        deactivate Pinecone
        note right of Server2
          Returns:
          - Vector: [0.245, -0.543, ...]
          - Metadata: {
              applicant_id, name,
              skills: ["Python", "React"],
              location, experience
            }
        end note
        
        == Vector Similarity Search ==
        
        Server2 -> Pinecone: 8. Query Similar Job Vectors
        activate Pinecone
        note right of Server2
          Query: {
            namespace: "jobs",
            vector: applicant_vector,
            top_k: 10,
            filter: {
              is_active: true,
              location: "Remote",
              job_type: "Full-time"
            },
            include_metadata: true
          }
        end note
        
        Pinecone -> Pinecone: 9. Compute Cosine Similarity
        note right of Pinecone
          Compares applicant vector
          with all job vectors
          using cosine similarity
          
          Similarity Score: 0.0 to 1.0
          (1.0 = perfect match)
        end note
        
        alt No Jobs Found
            Pinecone -> Server2: 10a. Empty Results
            deactivate Pinecone
            Server2 -> Server1: No Matching Jobs
            deactivate Server2
            Server1 -> Frontend: No Recommendations Available
            deactivate Server1
            Frontend -> Applicant: "No jobs match your profile yet"
            deactivate Frontend
        else Jobs Found
            Pinecone -> Server2: 10b. Top N Similar Jobs
            deactivate Pinecone
            note right of Pinecone
              Returns: [
                {
                  id: "job_123",
                  score: 0.92,
                  metadata: {
                    job_id, title,
                    company_name, location,
                    required_skills: [...],
                    description, salary...
                  }
                },
                ...
              ]
            end note
            
            == Enhanced Matching ==
            
            Server2 -> Server2: 11. Enhance Results with Skill Matching
            note right of Server2
              For each job:
              - Parse required_skills from metadata
              - Compare with applicant skills
              - Count matched skills
              - Calculate match percentage
              
              Example:
              Job requires: ["Python", "FastAPI", "React"]
              Applicant has: ["Python", "React", "Node.js"]
              Matched: ["Python", "React"] = 66% match
            end note
            
            Server2 -> Server2: 12. Rank Jobs by Combined Score
            note right of Server2
              Sorting criteria:
              1. Vector similarity score (primary)
              2. Skill match count (secondary)
              
              This ensures best matches appear first
            end note
            
            Server2 -> Server1: 13. Return Recommendations
            deactivate Server2
            note right of Server2
              Response: {
                success: true,
                applicant_id,
                total_jobs: 8,
                recommendations: [
                  {
                    job_id: "123",
                    title: "Senior Developer",
                    company_name: "TechCorp",
                    location: "Remote",
                    job_type: "Full-time",
                    experience_level: "Senior",
                    required_skills: [...],
                    similarity_score: 0.92,
                    matched_skills: ["Python", "React"],
                    skill_match_count: 2
                  },
                  ...
                ]
              }
            end note
            
            Server1 -> Frontend: 14. Forward Recommendations
            deactivate Server1
            
            Frontend -> Frontend: 15. Format Job Cards
            Frontend -> Applicant: 16. Display Recommended Jobs
            deactivate Frontend
            destroy Frontend
            
            note right of Applicant
              User sees:
              - Job title & company
              - Match score (92%)
              - Matched skills highlighted
              - Location, job type
              - Apply button
              
              Jobs sorted by relevance
            end note
        end
    end
end

@enduml
```

**Key Points:**
- **Starts:** User requests recommendations
- **Ends:** Personalized job list displayed
- **Alternative Flows:**
  - Token invalid → Login
  - Profile not synced → Prompt to update profile
  - No matching jobs → Show message
- **Key Feature:** Full microservices flow with vector similarity search
- **AI Logic:** Combines semantic matching + skill matching

---

## SD7: Apply for Job (Planned Feature)

**Use Case:** UC11
**Status:** 🔵 Planned
**Actors:** Applicant, Frontend, Server-1, MongoDB, NodeMailer
**Purpose:** Submit job application

```plantuml
@startuml
actor Applicant
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB
participant "NodeMailer\n(Email Service)" as Email

title SD7: Apply for Job (Planned)

Applicant -> Frontend: 1. View Job Details
activate Frontend
Frontend -> Applicant: 2. Display Job with "Apply" Button
deactivate Frontend

Applicant -> Frontend: 3. Click "Apply Now"
activate Frontend

Frontend -> Server1: 4. Check Profile Completion
activate Server1
Server1 -> DB: 5. Get Profile Status
activate DB
DB -> Server1: Profile Data
deactivate DB

alt Profile Incomplete
    Server1 -> Frontend: 6a. Profile Not Complete
    deactivate Server1
    Frontend -> Applicant: "Complete profile before applying"
    deactivate Frontend
else Profile Complete
    Server1 -> Frontend: 6b. Profile Complete
    deactivate Server1
    
    Frontend -> Applicant: 7. Show Application Form
    deactivate Frontend
    note right of Applicant
      Form includes:
      - Resume (auto-attached from profile)
      - Cover Letter (optional)
      - Additional questions (if any)
    end note
    
    Applicant -> Frontend: 8. Write Cover Letter (Optional)
    activate Frontend
    Applicant -> Frontend: 9. Click "Submit Application"
    
    Frontend -> Server1: 10. POST /api/applications/submit
    activate Server1
    note right of Server1
      Request Body: {
        job_id,
        applicant_id,
        cover_letter,
        profile_snapshot: {...},
        applied_at: timestamp
      }
    end note
    
    Server1 -> DB: 11. Check if Already Applied
    activate DB
    DB -> Server1: Application Status
    deactivate DB
    
    alt Already Applied
        Server1 -> Frontend: 12a. Duplicate Application
        deactivate Server1
        Frontend -> Applicant: "You already applied for this job"
        deactivate Frontend
    else First Application
        Server1 -> DB: 12b. Create Application Record
        activate DB
        note right of DB
          Collection: applications
          Data: {
            job_id,
            applicant_id,
            company_id,
            cover_letter,
            profile_snapshot,
            status: "pending",
            applied_at
          }
        end note
        DB -> Server1: Application Created
        deactivate DB
        
        par Parallel Notifications
            Server1 -> Email: 13. Notify Company
            activate Email
            note right of Email
              To: company.email
              Subject: "New Application"
              Body: Applicant details
            end note
            Email -> Server1: Email Sent
            deactivate Email
            
            Server1 -> Email: 14. Confirm to Applicant
            activate Email
            note right of Email
              To: applicant.email
              Subject: "Application Submitted"
              Body: Job details & next steps
            end note
            Email -> Server1: Email Sent
            deactivate Email
        end
        
        Server1 -> Frontend: 15. Application Success
        deactivate Server1
        Frontend -> Applicant: "Application Submitted Successfully!"
        deactivate Frontend
        destroy Frontend
        
        note right of Applicant
          Application tracking available
          User can check status later
        end note
    end
end

@enduml
```

**Key Points:**
- **Starts:** User clicks apply on a job
- **Ends:** Application submitted successfully
- **Alternative Flows:**
  - Profile incomplete
  - Already applied to this job
- **Status:** Planned (requires implementation)

---

## SD8: Participate in AI Interview (Planned Feature)

**Use Case:** UC16
**Status:** 🔵 Planned
**Actors:** Applicant, Frontend, Server-1, Server-2, MongoDB, OpenAI
**Purpose:** Complete automated AI-powered interview

```plantuml
@startuml
actor Applicant
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
participant "Server-2\n(FastAPI/AI)" as Server2
database "MongoDB" as DB
participant "OpenAI\n(GPT-4)" as OpenAI

title SD8: AI Interview Session (Planned)

== Interview Invitation ==

Applicant -> Applicant: Receives Interview Invitation Email
note right of Applicant
  Email contains:
  - Interview link
  - Deadline
  - Duration
  - Instructions
end note

Applicant -> Frontend: 1. Click Interview Link
activate Frontend
Frontend -> Server1: 2. GET /api/interviews/:interview_id
activate Server1

Server1 -> DB: 3. Fetch Interview Details
activate DB
DB -> Server1: Interview Data
deactivate DB

alt Interview Expired or Completed
    Server1 -> Frontend: 4a. Interview Not Available
    deactivate Server1
    Frontend -> Applicant: "Interview expired or already completed"
    deactivate Frontend
else Interview Active
    Server1 -> Frontend: 4b. Interview Details
    deactivate Server1
    note right of Server1
      Response: {
        interview_id,
        job_title,
        company_name,
        duration: 30,
        questions_count: 10,
        deadline
      }
    end note
    
    Frontend -> Applicant: 5. Show Interview Instructions
    deactivate Frontend
    note right of Applicant
      Instructions:
      - Time limit per question
      - Can't go back
      - Browser must stay focused
      - Webcam required (optional)
    end note
end

Applicant -> Frontend: 6. Click "Start Interview"
activate Frontend

Frontend -> Server1: 7. POST /api/interviews/:id/start
activate Server1
Server1 -> DB: 8. Create Interview Session
activate DB
DB -> Server1: Session Created
deactivate DB

Server1 -> Server2: 9. Request First Question
activate Server2

Server2 -> OpenAI: 10. Generate Interview Question
activate OpenAI
note right of Server2
  Prompt: Generate technical/behavioral
  question based on:
  - Job requirements
  - Applicant's skills
  - Question difficulty level
end note

OpenAI -> Server2: Question Generated
deactivate OpenAI

Server2 -> Server1: First Question
deactivate Server2
Server1 -> Frontend: Question + Timer
deactivate Server1

== Question-Answer Loop ==

loop For Each Question (10 questions)
    Frontend -> Applicant: Display Question
    activate Frontend
    note right of Applicant
      Question types:
      - Text answer
      - Video recording
      - Audio recording
      - Code snippet
    end note
    
    Frontend -> Frontend: Start Timer (e.g., 3 minutes)
    
    Applicant -> Frontend: Record/Type Answer
    
    alt Time Expired
        Frontend -> Frontend: Auto-submit answer
        note right of Frontend
          If user doesn't submit
          within time limit
        end note
    else User Submits
        Applicant -> Frontend: Click "Submit Answer"
    end
    
    Frontend -> Server1: POST /api/interviews/:id/submit-answer
    activate Server1
    note right of Server1
      Request Body: {
        question_id,
        answer: "text/audio/video",
        time_taken: 145 // seconds
      }
    end note
    
    Server1 -> DB: Save Answer
    activate DB
    DB -> Server1: Answer Saved
    deactivate DB
    
    Server1 -> Server2: Evaluate Answer
    activate Server2
    
    par Parallel AI Evaluation
        Server2 -> OpenAI: Analyze Text Content
        activate OpenAI
        note right of OpenAI
          Evaluates:
          - Accuracy
          - Completeness
          - Relevance
          - Communication quality
        end note
        OpenAI -> Server2: Content Score
        deactivate OpenAI
        
        opt If Video/Audio Answer
            Server2 -> OpenAI: Analyze Speech/Video
            activate OpenAI
            note right of OpenAI
              Evaluates:
              - Confidence level
              - Clarity
              - Body language
            end note
            OpenAI -> Server2: Presentation Score
            deactivate OpenAI
        end
    end
    
    Server2 -> Server2: Calculate Question Score
    Server2 -> Server1: Evaluation Complete
    deactivate Server2
    
    alt More Questions Remaining
        Server1 -> Server2: Request Next Question
        activate Server2
        Server2 -> OpenAI: Generate Next Question
        activate OpenAI
        OpenAI -> Server2: Question
        deactivate OpenAI
        Server2 -> Server1: Next Question
        deactivate Server2
        Server1 -> Frontend: Next Question + Timer
        deactivate Server1
    else All Questions Answered
        Server1 -> Frontend: Interview Complete
        deactivate Server1
        deactivate Frontend
    end
end

== Interview Completion ==

Frontend -> Server1: POST /api/interviews/:id/complete
activate Frontend
activate Server1

Server1 -> Server2: Generate Final Report
activate Server2

Server2 -> Server2: Aggregate All Scores
note right of Server2
  Overall Score:
  - Technical: 85/100
  - Communication: 78/100
  - Problem Solving: 90/100
  - Overall: 84/100
end note

Server2 -> Server2: Generate Insights
note right of Server2
  AI generates:
  - Strengths
  - Areas for improvement
  - Question-wise breakdown
  - Comparison with others
end note

Server2 -> Server1: Interview Report
deactivate Server2

Server1 -> DB: Save Final Report
activate DB
DB -> Server1: Report Saved
deactivate DB

Server1 -> DB: Notify Company
activate DB
note right of DB
  Update application status
  to "Interview Completed"
end note
DB -> Server1: Updated
deactivate DB

Server1 -> Frontend: Interview Completion Confirmed
deactivate Server1

Frontend -> Applicant: "Interview Completed! Results sent to company"
deactivate Frontend
destroy Frontend

note right of Applicant
  Interview finished
  Can view summary
  Company will review results
end note

@enduml
```

**Key Points:**
- **Starts:** User clicks interview invitation link
- **Ends:** Interview completed and report generated
- **Alternative Flows:**
  - Interview expired
  - Time limit per question
  - Auto-submit on timeout
- **Status:** Planned (requires full implementation)
- **Key Features:**
  - Real-time AI question generation
  - Multi-modal response evaluation
  - Automated scoring

---

# 🏢 COMPANY SEQUENCE DIAGRAMS <a name="company-sequences"></a>

## SD9: Company Registration & Verification

**Use Case:** UC17
**Actors:** Company Rep, Frontend, Server-1, MongoDB, NodeMailer
**Purpose:** Register company account

```plantuml
@startuml
actor "Company Rep" as Company
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB
participant "NodeMailer\n(Email Service)" as Email

title SD9: Company Registration & Verification

Company -> Frontend: 1. Navigate to Signup Page
activate Frontend
Frontend -> Company: 2. Display Signup Form
deactivate Frontend

Company -> Frontend: 3. Select "Company" Role
activate Frontend
Company -> Frontend: 4. Fill Company Details
note right of Company
  Required Fields:
  - Company Name
  - Email
  - Password
  - Phone
  - Website (optional)
  - Location
  - Company Size
  - Industry
end note

Frontend -> Frontend: 5. Client-side Validation

alt Validation Fails
    Frontend -> Company: 6a. Show Validation Errors
    deactivate Frontend
else Validation Success
    Frontend -> Server1: 6b. POST /api/companies/register
    activate Server1
    note right of Server1
      Request Body: {
        company_name,
        company_email,
        password,
        phone_no,
        website,
        location,
        company_size,
        industry
      }
    end note
    
    Server1 -> Server1: 7. Server-side Validation
    
    Server1 -> DB: 8. Check if Email Exists
    activate DB
    DB -> Server1: Email Status
    deactivate DB
    
    alt Email Already Exists
        Server1 -> Frontend: 9a. Email Already Registered
        deactivate Server1
        Frontend -> Company: Show Error Message
        deactivate Frontend
    else Email Available
        Server1 -> Server1: 9b. Hash Password
        
        Server1 -> DB: 10. Create User Record
        activate DB
        note right of DB
          Collection: users
          Data: {
            email,
            hashed_password,
            role: "company",
            is_verified: false
          }
        end note
        DB -> Server1: User Created (user_id)
        deactivate DB
        
        Server1 -> DB: 11. Create Company Record
        activate DB
        note right of DB
          Collection: companies
          Data: {
            user_id,
            company_name,
            company_email,
            phone_no,
            website,
            location,
            company_size,
            industry
          }
        end note
        DB -> Server1: Company Created
        deactivate DB
        
        Server1 -> Server1: 12. Generate OTP
        
        Server1 -> DB: 13. Save OTP to User
        activate DB
        DB -> Server1: OTP Saved
        deactivate DB
        
        Server1 -> Email: 14. Send Verification Email
        activate Email
        note right of Email
          To: company.email
          Subject: "Verify Company Email"
          Body: OTP code + instructions
        end note
        Email -> Server1: Email Sent
        deactivate Email
        
        Server1 -> Frontend: 15. Registration Success
        deactivate Server1
        Frontend -> Company: "Check Email for Verification"
        deactivate Frontend
        
        == Email Verification ==
        
        Company -> Frontend: 16. Enter OTP
        activate Frontend
        Frontend -> Server1: 17. POST /api/auth/verify-email
        activate Server1
        
        Server1 -> DB: 18. Verify OTP
        activate DB
        
        alt OTP Invalid/Expired
            DB -> Server1: Invalid OTP
            deactivate DB
            Server1 -> Frontend: 19a. OTP Invalid
            deactivate Server1
            Frontend -> Company: "Invalid OTP. Resend?"
            deactivate Frontend
        else OTP Valid
            DB -> Server1: 19b. OTP Valid
            deactivate DB
            
            Server1 -> DB: 20. Update User (is_verified = true)
            activate DB
            DB -> Server1: User Verified
            deactivate DB
            
            Server1 -> Frontend: 21. Verification Success
            deactivate Server1
            Frontend -> Company: "Email Verified! You can now login"
            deactivate Frontend
            destroy Frontend
            
            note right of Company
              Company can now:
              - Login to system
              - Post jobs (after email verified)
            end note
        end
    end
end

@enduml
```

**Key Points:**
- **Starts:** Company rep fills registration form
- **Ends:** Email verified, account active
- **Alternative Flows:**
  - Email already exists
  - Invalid/expired OTP

---

## SD10: Job Posting with AI Vectorization

**Use Case:** UC21
**Actors:** Company Rep, Frontend, Server-1, MongoDB, Server-2, Pinecone, OpenAI
**Purpose:** Post job and sync to AI recommendation system

```plantuml
@startuml
actor "Company Rep" as Company
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB
participant "Server-2\n(FastAPI)" as Server2
participant "OpenAI\nEmbeddings API" as OpenAI
database "Pinecone\n(Vector DB)" as Pinecone

title SD10: Job Posting with AI Vectorization

Company -> Frontend: 1. Navigate to "Post Job" Page
activate Frontend
Frontend -> Company: 2. Display Job Form
deactivate Frontend

Company -> Frontend: 3. Fill Job Details
activate Frontend
note right of Company
  Required Fields:
  - Title
  - Department
  - Location
  - Job Type (Full-time, Part-time, etc.)
  - Work Mode (Remote, On-site, Hybrid)
  - Experience Required
  - Salary Range (min-max)
  - Positions
  - Deadline
  - Description (min 50 chars)
  - Responsibilities
  - Requirements
  - Benefits (optional)
  - Required Skills (comma-separated)
end note

Company -> Frontend: 4. Choose: "Save as Draft" or "Post Job"
Frontend -> Frontend: 5. Client-side Validation

alt Validation Fails
    Frontend -> Company: 6a. Show Validation Errors
    deactivate Frontend
else Validation Success
    Frontend -> Server1: 6b. POST /api/company/jobs
    activate Server1
    note right of Server1
      Request Body: {
        title, department, location,
        jobType, workMode, experience,
        salaryMin, salaryMax, positions,
        deadline, description,
        responsibilities, requirements,
        benefits, skills,
        isDraft: true/false
      }
      Headers: {
        Authorization: Bearer TOKEN
      }
    end note
    
    Server1 -> Server1: 7. Verify JWT Token & Extract userId
    
    alt Token Invalid
        Server1 -> Frontend: 8a. Unauthorized (401)
        deactivate Server1
        Frontend -> Company: Redirect to Login
        deactivate Frontend
    else Token Valid
        Server1 -> DB: 8b. Get User Record
        activate DB
        DB -> Server1: User Data
        deactivate DB
        
        alt Email Not Verified
            Server1 -> Frontend: 9a. Email Not Verified
            deactivate Server1
            Frontend -> Company: "Verify email before posting jobs"
            deactivate Frontend
        else Email Verified
            Server1 -> DB: 9b. Get Company Profile
            activate DB
            DB -> Server1: Company Data
            deactivate DB
            
            Server1 -> Server1: 10. Validate Job Data
            note right of Server1
              Validations:
              - salaryMax >= salaryMin
              - deadline > today
              - valid jobType & workMode
              - positions >= 1
              - description >= 50 chars
            end note
            
            alt Validation Fails
                Server1 -> Frontend: 11a. Validation Errors
                deactivate Server1
                Frontend -> Company: Show Specific Errors
                deactivate Frontend
            else Validation Success
                Server1 -> Server1: 11b. Determine Status
                note right of Server1
                  status = isDraft ? "draft" : "active"
                  posted_at = active ? now : null
                end note
                
                Server1 -> DB: 12. Create Job Record
                activate DB
                note right of DB
                  Collection: jobposts
                  Data: {
                    company_id,
                    user_id,
                    title, location, jobType,
                    ... (all fields),
                    status: "draft" or "active",
                    is_deleted: false,
                    posted_at
                  }
                end note
                DB -> Server1: Job Created (job._id)
                deactivate DB
                
                alt Saved as Draft
                    Server1 -> Frontend: 13a. Draft Saved
                    deactivate Server1
                    Frontend -> Company: "Job Saved as Draft"
                    deactivate Frontend
                    note right of Company
                      Draft not sent to AI service
                      Can edit and publish later
                    end note
                else Job Published (Active)
                    == AI Service Integration ==
                    
                    Server1 -> Server2: 13b. POST /api/jobs/ingest
                    activate Server2
                    note right of Server1
                      Request to AI Service:
                      {
                        job_id: job._id.toString(),
                        title,
                        company_id,
                        company_name,
                        location,
                        job_type: jobType,
                        experience_level: experience,
                        description,
                        required_skills: skills.split(','),
                        preferred_skills: [],
                        responsibilities,
                        qualifications: requirements,
                        salary_min: salaryMin,
                        salary_max: salaryMax,
                        salary_currency: "USD",
                        is_active: true
                      }
                    end note
                    
                    Server2 -> Server2: 14. Prepare Job Text
                    note right of Server2
                      Combined Text:
                      "Job Title: {title} |
                       Company: {company_name} |
                       Location: {location} |
                       Skills: {required_skills} |
                       Description: {description} |
                       Responsibilities: {responsibilities}"
                    end note
                    
                    Server2 -> OpenAI: 15. Generate Embedding
                    activate OpenAI
                    note right of OpenAI
                      Model: text-embedding-3-small
                      Input: Combined job text
                      Output: 1536-dimensional vector
                    end note
                    OpenAI -> Server2: Embedding Vector [0.234, -0.567, ...]
                    deactivate OpenAI
                    
                    Server2 -> Pinecone: 16. Upsert Job Vector
                    activate Pinecone
                    note right of Pinecone
                      Namespace: "jobs"
                      Vector ID: job_{job_id}
                      Vector: embedding array
                      Metadata: {
                        job_id, title,
                        company_id, company_name,
                        location, job_type,
                        experience_level,
                        required_skills, description,
                        salary_min, salary_max,
                        is_active: true
                      }
                    end note
                    Pinecone -> Server2: Vector Stored
                    deactivate Pinecone
                    
                    Server2 -> Server1: 17. Ingestion Success
                    deactivate Server2
                    note right of Server2
                      Response: {
                        success: true,
                        message: "Job ingested",
                        job_id,
                        vector_id: "job_{job_id}"
                      }
                    end note
                    
                    opt AI Service Failed
                        Server2 -> Server1: AI Service Error
                        note right of Server1
                          Job still posted in MongoDB
                          AI sync failed gracefully
                          Can be retried later
                        end note
                    end
                    
                    Server1 -> Frontend: 18. Job Posted Successfully
                    deactivate Server1
                    Frontend -> Company: "Job Posted & Synced to AI System!"
                    deactivate Frontend
                    destroy Frontend
                    
                    note right of Company
                      Job is now:
                      - Visible to applicants
                      - Available in AI recommendations
                      - Searchable by vector similarity
                    end note
                end
            end
        end
    end
end

@enduml
```

**Key Points:**
- **Starts:** Company fills job posting form
- **Ends:** Job published and synced to AI system
- **Alternative Flows:**
  - Token invalid → Login
  - Email not verified → Verify first
  - Validation errors → Show errors
  - Save as draft → Don't sync to AI
  - AI service fails → Job still posted
- **Key Feature:** Microservices integration with vector database

---

## SD11: Update Job Post with AI Re-sync

**Use Case:** UC24
**Actors:** Company Rep, Frontend, Server-1, MongoDB, Server-2, Pinecone
**Purpose:** Update job and re-sync to AI system

```plantuml
@startuml
actor "Company Rep" as Company
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB
participant "Server-2\n(FastAPI)" as Server2
database "Pinecone\n(Vector DB)" as Pinecone

title SD11: Update Job Post with AI Re-sync

Company -> Frontend: 1. Navigate to "My Jobs"
activate Frontend
Frontend -> Server1: 2. GET /api/company/jobs
activate Server1
Server1 -> DB: 3. Fetch Company's Jobs
activate DB
DB -> Server1: Jobs List
deactivate DB
Server1 -> Frontend: Jobs Data
deactivate Server1
Frontend -> Company: Display Jobs List
deactivate Frontend

Company -> Frontend: 4. Click "Edit" on a Job
activate Frontend
Frontend -> Server1: 5. GET /api/company/jobs/:job_id
activate Server1
Server1 -> DB: 6. Fetch Job Details
activate DB
DB -> Server1: Job Data
deactivate DB
Server1 -> Frontend: Job Details
deactivate Server1
Frontend -> Company: Display Pre-filled Form
deactivate Frontend

Company -> Frontend: 7. Modify Job Information
activate Frontend
note right of Company
  Can update any fields:
  - Title, description
  - Skills required
  - Salary, locations
  - Deadline, etc.
end note

Company -> Frontend: 8. Click "Update Job"
Frontend -> Server1: 9. PUT /api/company/jobs/:job_id
activate Server1
note right of Server1
  Request Body: {
    title, department, location,
    jobType, workMode, experience,
    salaryMin, salaryMax,
    description, responsibilities,
    requirements, skills,
    status, etc.
  }
  Headers: Authorization
end note

Server1 -> Server1: 10. Verify Token & Ownership
note right of Server1
  Check:
  - Valid JWT token
  - Company owns this job
end note

alt Not Authorized
    Server1 -> Frontend: 11a. Unauthorized/Forbidden
    deactivate Server1
    Frontend -> Company: "Access Denied"
    deactivate Frontend
else Authorized
    Server1 -> DB: 11b. Fetch Current Job
    activate DB
    DB -> Server1: Job Data
    deactivate DB
    
    Server1 -> Server1: 12. Validate Updates
    
    alt Validation Fails
        Server1 -> Frontend: 13a. Validation Errors
        deactivate Server1
        Frontend -> Company: Show Errors
        deactivate Frontend
    else Validation Success
        Server1 -> DB: 13b. Update Job Record
        activate DB
        note right of DB
          Update all modified fields
          Keep original created_at
          Update updated_at timestamp
        end note
        DB -> Server1: Job Updated
        deactivate DB
        
        alt Job Status is "draft"
            Server1 -> Frontend: 14a. Draft Updated
            deactivate Server1
            Frontend -> Company: "Draft Saved"
            deactivate Frontend
            note right of Company
              Draft updated in MongoDB only
              Not synced to AI
            end note
        else Job Status is "active"
            == Re-sync to AI System ==
            
            Server1 -> Server2: 14b. PUT /api/jobs/update
            activate Server2
            note right of Server1
              Request: {
                job_id,
                updates: {
                  ... (all job data)
                }
              }
            end note
            
            Server2 -> Server2: 15. Re-prepare Job Text
            note right of Server2
              Create updated combined text
              with new job details
            end note
            
            Server2 -> OpenAI: 16. Generate New Embedding
            activate OpenAI
            OpenAI -> Server2: Updated Vector
            deactivate OpenAI
            
            Server2 -> Pinecone: 17. Update Job Vector
            activate Pinecone
            note right of Pinecone
              Upsert operation:
              - Same vector_id: job_{job_id}
              - New vector values
              - Updated metadata
              
              Replaces old job data
            end note
            Pinecone -> Server2: Vector Updated
            deactivate Pinecone
            
            Server2 -> Server1: 18. Update Success
            deactivate Server2
            
            opt AI Update Failed
                Server2 -> Server1: AI Service Error
                note right of Server1
                  Job updated in MongoDB
                  AI sync failed but job still active
                end note
            end
            
            Server1 -> Frontend: 19. Job Updated Successfully
            deactivate Server1
            Frontend -> Company: "Job Updated & Re-synced!"
            deactivate Frontend
            destroy Frontend
            
            note right of Company
              Updated job now:
              - Shows new information
              - Has updated vector in AI
              - Matches different profiles
            end note
        end
    end
end

@enduml
```

**Key Points:**
- **Starts:** Company edits a job
- **Ends:** Job updated and re-synced to AI
- **Alternative Flows:**
  - Unauthorized access
  - Validation errors
  - Draft vs Active (only active re-syncs)
  - AI service failure (handled gracefully)

---

## SD12: Delete Job Post (Soft Delete with AI Cleanup)

**Use Case:** UC25
**Actors:** Company Rep, Frontend, Server-1, MongoDB, Server-2, Pinecone
**Purpose:** Soft delete job and remove from AI system

```plantuml
@startuml
actor "Company Rep" as Company
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB
participant "Server-2\n(FastAPI)" as Server2
database "Pinecone\n(Vector DB)" as Pinecone

title SD12: Delete Job Post (Soft Delete with AI Cleanup)

Company -> Frontend: 1. View "My Jobs" Page
activate Frontend
Frontend -> Company: Display Jobs List
deactivate Frontend

Company -> Frontend: 2. Click "Delete" Button
activate Frontend
Frontend -> Company: Show Confirmation Dialog
deactivate Frontend
note right of Company
  Dialog: "Are you sure you want
  to delete this job posting?
  This action cannot be undone."
end note

Company -> Frontend: 3. Confirm Delete
activate Frontend

Frontend -> Server1: 4. DELETE /api/company/jobs/:job_id
activate Server1
note right of Server1
  Headers: {
    Authorization: Bearer TOKEN
  }
end note

Server1 -> Server1: 5. Verify Token & Extract userId

alt Token Invalid
    Server1 -> Frontend: 6a. Unauthorized (401)
    deactivate Server1
    Frontend -> Company: Redirect to Login
    deactivate Frontend
else Token Valid
    Server1 -> DB: 6b. Get Company ID
    activate DB
    DB -> Server1: Company Data
    deactivate DB
    
    Server1 -> DB: 7. Fetch Job
    activate DB
    note right of Server1
      Query: {
        _id: job_id,
        company_id: company._id
      }
    end note
    
    alt Job Not Found or Not Owned
        DB -> Server1: Job Not Found
        deactivate DB
        Server1 -> Frontend: 8a. Job Not Found (404)
        deactivate Server1
        Frontend -> Company: "Job not found or access denied"
        deactivate Frontend
    else Job Found and Owned
        DB -> Server1: 8b. Job Data
        deactivate DB
        
        == Soft Delete in MongoDB ==
        
        Server1 -> DB: 9. Perform Soft Delete
        activate DB
        note right of DB
          Update: {
            is_deleted: true,
            deleted_at: new Date()
          }
          
          Job remains in database
          but not shown to applicants
        end note
        DB -> Server1: Job Soft Deleted
        deactivate DB
        
        == Remove from AI System ==
        
        Server1 -> Server2: 10. DELETE /api/jobs/delete
        activate Server2
        note right of Server1
          Request Body: {
            job_id: job_id
          }
        end note
        
        Server2 -> Pinecone: 11. Delete Job Vector
        activate Pinecone
        note right of Pinecone
          Delete Operation:
          {
            namespace: "jobs",
            ids: ["job_{job_id}"]
          }
          
          Removes job from vector database
          No longer appears in recommendations
        end note
        
        alt Vector Deletion Success
            Pinecone -> Server2: 12a. Vector Deleted
            deactivate Pinecone
            Server2 -> Server1: Deletion Success
            deactivate Server2
            note right of Server2
              Response: {
                success: true,
                message: "Job deleted",
                job_id
              }
            end note
        else Vector Deletion Failed
            Pinecone -> Server2: 12b. Deletion Error
            deactivate Pinecone
            Server2 -> Server1: AI Service Error
            deactivate Server2
            note right of Server1
              Job still soft-deleted in MongoDB
              AI cleanup failed but
              job won't appear to users anyway
            end note
        end
        
        Server1 -> Frontend: 13. Job Deleted Successfully
        deactivate Server1
        note right of Server1
          Response: {
            success: true,
            message: "Job deleted successfully"
          }
        end note
        
        Frontend -> Frontend: 14. Remove Job from List (UI)
        Frontend -> Company: "Job Deleted Successfully"
        deactivate Frontend
        destroy Frontend
        
        note right of Company
          Job now:
          - Marked as deleted in MongoDB
          - Removed from AI recommendations
          - Not visible to applicants
          - Still exists in database (audit trail)
        end note
    end
end

@enduml
```

**Key Points:**
- **Starts:** Company confirms deletion
- **Ends:** Job soft-deleted and removed from AI
- **Alternative Flows:**
  - Token invalid → Login
  - Job not found or not owned → Error
  - AI deletion fails → Job still hidden
- **Key Feature:** Soft delete (keeps audit trail) + AI cleanup

---

## SD13: View Job Applications (Planned Feature)

**Use Case:** UC26
**Status:** 🔵 Planned
**Actors:** Company Rep, Frontend, Server-1, MongoDB, Server-2
**Purpose:** View applicants who applied for a job with AI match scores

```plantuml
@startuml
actor "Company Rep" as Company
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB
participant "Server-2\n(FastAPI/AI)" as Server2

title SD13: View Job Applications with AI Scores (Planned)

Company -> Frontend: 1. Navigate to "My Jobs"
activate Frontend
Frontend -> Company: Display Jobs with Application Counts
deactivate Frontend
note right of Company
  Each job shows:
  - Job title
  - Applications count
  - Active/Closed status
end note

Company -> Frontend: 2. Click "View Applications" on a Job
activate Frontend

Frontend -> Server1: 3. GET /api/company/jobs/:job_id/applications
activate Server1
note right of Server1
  Headers: Authorization
end note

Server1 -> Server1: 4. Verify Token & Job Ownership

alt Not Authorized
    Server1 -> Frontend: 5a. Unauthorized
    deactivate Server1
    Frontend -> Company: "Access Denied"
    deactivate Frontend
else Authorized
    Server1 -> DB: 5b. Fetch Applications for Job
    activate DB
    note right of DB
      Query: {
        job_id: job_id,
        status: { $ne: "withdrawn" }
      }
      
      Join with:
      - Applicant profile
      - User data
    end note
    DB -> Server1: Applications List
    deactivate DB
    
    alt No Applications Yet
        Server1 -> Frontend: 6a. Empty List
        deactivate Server1
        Frontend -> Company: "No applications received yet"
        deactivate Frontend
    else Has Applications
        == Enhance with AI Match Scores ==
        
        loop For Each Application
            Server1 -> Server2: 6b. POST /api/matching/calculate-score
            activate Server2
            note right of Server1
              Request: {
                job_id,
                applicant_id
              }
            end note
            
            Server2 -> Server2: 7. Calculate Match Score
            note right of Server2
              Scoring based on:
              - Vector similarity
              - Skill match %
              - Experience alignment
              - Education fit
              
              Overall Score: 0-100
            end note
            
            Server2 -> Server1: AI Match Score
            deactivate Server2
            note right of Server2
              Response: {
                match_score: 87,
                skill_match_percentage: 85,
                experience_match: "Excellent",
                recommendation: "Strong Candidate"
              }
            end note
        end
        
        Server1 -> Server1: 8. Sort by Match Score (Descending)
        
        Server1 -> Frontend: 9. Applications with Scores
        deactivate Server1
        note right of Server1
          Response: {
            success: true,
            job_title: "...",
            total_applications: 25,
            applications: [
              {
                application_id,
                applicant: {
                  name, email,
                  current_role,
                  skills: [...],
                  experience: 5
                },
                cover_letter,
                applied_at,
                status: "pending",
                ai_match_score: 87,
                skill_match_percentage: 85,
                matched_skills: [...],
                recommendation: "Strong Candidate"
              },
              ...
            ]
          }
        end note
        
        Frontend -> Frontend: 10. Display Applications
        Frontend -> Company: Show Ranked Applicant List
        deactivate Frontend
        destroy Frontend
        
        note right of Company
          Company sees:
          - Applicants sorted by AI score
          - Match percentage highlighted
          - Matched skills
          - Quick actions: View, Shortlist, Reject
        end note
    end
end

@enduml
```

**Key Points:**
- **Starts:** Company views applications for a job
- **Ends:** Applications displayed with AI match scores
- **Alternative Flows:**
  - No applications yet
  - Unauthorized access
- **Status:** Planned
- **Key Feature:** AI-enhanced applicant ranking

---

## SD14: Schedule AI Interview (Planned Feature)

**Use Case:** UC28
**Status:** 🔵 Planned
**Actors:** Company Rep, Frontend, Server-1, Server-2, MongoDB, NodeMailer
**Purpose:** Schedule automated AI interview for shortlisted candidates

```plantuml
@startuml
actor "Company Rep" as Company
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB
participant "Server-2\n(FastAPI/AI)" as Server2
participant "NodeMailer\n(Email)" as Email

title SD14: Schedule AI Interview (Planned)

Company -> Frontend: 1. View Shortlisted Candidates
activate Frontend
Frontend -> Company: Display Shortlisted List
deactivate Frontend

Company -> Frontend: 2. Select Candidates for Interview
activate Frontend
note right of Company
  Can select:
  - Single candidate
  - Multiple candidates
  - All shortlisted
end note

Company -> Frontend: 3. Click "Schedule AI Interview"
Frontend -> Company: Show Interview Configuration Form
deactivate Frontend

Company -> Frontend: 4. Configure Interview Settings
activate Frontend
note right of Company
  Settings:
  - Interview Type (Technical, HR, Both)
  - Duration (15-60 minutes)
  - Question Count (5-20)
  - Difficulty Level
  - Deadline (when to complete by)
  - Custom questions (optional)
end note

Company -> Frontend: 5. Click "Schedule Interviews"
Frontend -> Server1: 6. POST /api/interviews/schedule
activate Server1
note right of Server1
  Request Body: {
    job_id,
    applicant_ids: [...],
    interview_config: {
      type: "technical",
      duration: 30,
      question_count: 10,
      difficulty: "intermediate",
      deadline: "2026-02-15",
      custom_questions: [...]
    }
  }
end note

Server1 -> Server1: 7. Verify Authorization

alt Not Authorized
    Server1 -> Frontend: 8a. Unauthorized
    deactivate Server1
    Frontend -> Company: "Access Denied"
    deactivate Frontend
else Authorized
    Server1 -> DB: 8b. Validate Applicants Status
    activate DB
    note right of DB
      Check all applicants are:
      - Actually applied to this job
      - Status is "shortlisted"
      - Not already interviewed
    end note
    DB -> Server1: Validation Result
    deactivate DB
    
    alt Validation Fails
        Server1 -> Frontend: 9a. Invalid Applicants
        deactivate Server1
        Frontend -> Company: Show Error Details
        deactivate Frontend
    else Validation Success
        par For Each Applicant (Parallel Processing)
            Server1 -> Server2: 9b. POST /api/interviews/create
            activate Server2
            note right of Server1
              Request for each applicant: {
                job_id,
                applicant_id,
                company_id,
                interview_config: {...}
              }
            end note
            
            Server2 -> Server2: 10. Generate Interview Plan
            note right of Server2
              AI generates:
              - Question set based on:
                * Job requirements
                * Applicant skills
                * Difficulty level
              - Question order
              - Scoring rubrics
            end note
            
            Server2 -> DB: 11. Save Interview Session
            activate DB
            note right of DB
              Collection: interviews
              Data: {
                interview_id,
                job_id,
                applicant_id,
                company_id,
                config: {...},
                questions: [...],
                status: "scheduled",
                created_at,
                deadline
              }
            end note
            DB -> Server2: Interview Created
            deactivate DB
            
            Server2 -> Server1: Interview Session Created
            deactivate Server2
            note right of Server2
              Response: {
                success: true,
                interview_id,
                interview_link,
                deadline
              }
            end note
            
            == Send Email Invitation ==
            
            Server1 -> Email: 12. Send Interview Invitation
            activate Email
            note right of Email
              To: applicant.email
              Subject: "AI Interview Invitation"
              Body:
              - Company name
              - Job title
              - Interview link
              - Deadline
              - Duration
              - Instructions
            end note
            Email -> Server1: Email Sent
            deactivate Email
            
            Server1 -> DB: 13. Update Application Status
            activate DB
            note right of DB
              Update: {
                status: "interview_scheduled",
                interview_id,
                interview_scheduled_at
              }
            end note
            DB -> Server1: Status Updated
            deactivate DB
        end
        
        Server1 -> Frontend: 14. All Interviews Scheduled
        deactivate Server1
        note right of Server1
          Response: {
            success: true,
            message: "Interviews scheduled",
            scheduled_count: 5,
            interviews: [...]
          }
        end note
        
        Frontend -> Company: "5 Interviews Scheduled Successfully!"
        deactivate Frontend
        destroy Frontend
        
        note right of Company
          Interviews scheduled
          Candidates notified via email
          Can track interview completion
        end note
    end
end

@enduml
```

**Key Points:**
- **Starts:** Company selects candidates and configures interview
- **Ends:** AI interviews scheduled and invitations sent
- **Alternative Flows:**
  - Unauthorized
  - Invalid candidates (not shortlisted)
  - Email delivery failures
- **Status:** Planned
- **Key Feature:** AI-powered interview generation and automated scheduling

---

# 👨‍💼 ADMIN SEQUENCE DIAGRAMS <a name="admin-sequences"></a>

## SD15: Admin Login & Dashboard Access

**Use Case:** UC32
**Status:** 🔵 Planned
**Actors:** Admin, Frontend, Server-1, MongoDB
**Purpose:** Admin authentication and dashboard access

```plantuml
@startuml
actor Admin
participant "Frontend\n(Next.js)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB

title SD15: Admin Login & Dashboard Access (Planned)

Admin -> Frontend: 1. Navigate to Admin Login (/admin/login)
activate Frontend
Frontend -> Admin: 2. Display Admin Login Form
deactivate Frontend
note right of Admin
  Separate admin login page
  Different from regular user login
end note

Admin -> Frontend: 3. Enter Admin Credentials
activate Frontend
note right of Admin
  Email & Password
  (Admins have admin role in DB)
end note

Frontend -> Frontend: 4. Client Validation

Frontend -> Server1: 5. POST /api/admin/auth/login
activate Server1
note right of Server1
  Request Body: {
    email,
    password
  }
end note

Server1 -> DB: 6. Find User by Email
activate DB
DB -> Server1: User Data (or null)
deactivate DB

alt User Not Found
    Server1 -> Frontend: 7a. Invalid Credentials
    deactivate Server1
    Frontend -> Admin: "Invalid email or password"
    deactivate Frontend
else User Found
    Server1 -> Server1: 7b. Verify Password
    
    alt Password Incorrect
        Server1 -> Frontend: 8a. Invalid Credentials
        deactivate Server1
        Frontend -> Admin: "Invalid email or password"
        deactivate Frontend
    else Password Correct
        Server1 -> Server1: 8b. Check Role
        
        alt Role is NOT "admin"
            Server1 -> Frontend: 9a. Unauthorized
            deactivate Server1
            Frontend -> Admin: "Access Denied - Admin Only"
            deactivate Frontend
        else Role is "admin"
            Server1 -> Server1: 9b. Generate Admin JWT Token
            note right of Server1
              Token Payload: {
                userId,
                userRole: "admin",
                permissions: [...]
              }
              Expires: 8 hours
            end note
            
            Server1 -> Frontend: 10. Login Success
            deactivate Server1
            note right of Server1
              Response: {
                success: true,
                token: "ADMIN_JWT_TOKEN",
                admin: {
                  name, email,
                  role: "admin",
                  permissions
                }
              }
            end note
            
            Frontend -> Frontend: 11. Store Admin Token
            note right of Frontend
              Stored separately from user tokens
              Different permission level
            end note
            
            Frontend -> Admin: 12. Redirect to Admin Dashboard
            deactivate Frontend
            destroy Frontend
            
            note right of Admin
              Admin Dashboard shows:
              - Platform statistics
              - Pending verifications
              - System health
              - AI service metrics
              - Recent activities
            end note
        end
    end
end

@enduml
```

**Key Points:**
- **Starts:** Admin enters admin portal
- **Ends:** Admin dashboard displayed
- **Alternative Flows:**
  - Invalid credentials
  - Non-admin user attempts access
- **Status:** Planned
- **Security:** Separate admin token with limited expiry

---

## SD16: Verify Company Account (Admin Action)

**Use Case:** UC31, UC34
**Status:** 🔵 Planned
**Actors:** Admin, Frontend, Server-1, MongoDB, NodeMailer
**Purpose:** Admin verifies company legitimacy

```plantuml
@startuml
actor Admin
participant "Frontend\n(Admin Panel)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
database "MongoDB" as DB
participant "NodeMailer\n(Email)" as Email

title SD16: Admin Verifies Company Account (Planned)

Admin -> Frontend: 1. Navigate to "Pending Verifications"
activate Frontend

Frontend -> Server1: 2. GET /api/admin/companies/pending
activate Server1
note right of Server1
  Headers: {
    Authorization: Bearer ADMIN_TOKEN
  }
end note

Server1 -> Server1: 3. Verify Admin Token

alt Token Invalid or Not Admin
    Server1 -> Frontend: 4a. Unauthorized
    deactivate Server1
    Frontend -> Admin: Redirect to Admin Login
    deactivate Frontend
else Valid Admin Token
    Server1 -> DB: 4b. Fetch Pending Companies
    activate DB
    note right of DB
      Query: {
        is_verified: false,
        is_email_verified: true
      }
      
      Companies waiting for admin approval
    end note
    DB -> Server1: Pending Companies List
    deactivate DB
    
    Server1 -> Frontend: 5. Pending Companies Data
    deactivate Server1
    note right of Server1
      Response: {
        success: true,
        count: 8,
        companies: [
          {
            company_id,
            company_name,
            email,
            website,
            location,
            industry,
            company_size,
            registered_at,
            documents: [...]
          },
          ...
        ]
      }
    end note
    
    Frontend -> Admin: 6. Display Pending Companies
    deactivate Frontend
    note right of Admin
      List shows:
      - Company details
      - Registration date
      - Documents submitted
      - Actions: Verify / Reject
    end note
end

Admin -> Frontend: 7. Click on Company to Review
activate Frontend
Frontend -> Admin: Show Detailed Company Profile
deactivate Frontend
note right of Admin
  Reviews:
  - Business registration
  - Website legitimacy
  - Contact information
  - Industry verification
end note

Admin -> Frontend: 8. Make Decision: Verify or Reject
activate Frontend

alt Admin Rejects Company
    Frontend -> Server1: 9a. POST /api/admin/companies/:id/reject
    activate Server1
    note right of Server1
      Request Body: {
        reason: "Invalid documents"
      }
    end note
    
    Server1 -> DB: Update Company Record
    activate DB
    note right of DB
      Set: {
        is_verified: false,
        verification_status: "rejected",
        rejection_reason,
        reviewed_by: admin_id,
        reviewed_at
      }
    end note
    DB -> Server1: Company Rejected
    deactivate DB
    
    Server1 -> Email: Send Rejection Email
    activate Email
    note right of Email
      To: company.email
      Subject: "Company Verification - Action Required"
      Body: Rejection reason & next steps
    end note
    Email -> Server1: Email Sent
    deactivate Email
    
    Server1 -> Frontend: Rejection Complete
    deactivate Server1
    Frontend -> Admin: "Company Rejected & Notified"
    deactivate Frontend
    
else Admin Verifies Company
    Frontend -> Server1: 9b. POST /api/admin/companies/:id/verify
    activate Server1
    note right of Server1
      Request Body: {
        notes: "Verified documents"
      }
    end note
    
    Server1 -> DB: Update Company Record
    activate DB
    note right of DB
      Set: {
        is_verified: true,
        verification_status: "verified",
        verification_notes,
        verified_by: admin_id,
        verified_at
      }
    end note
    DB -> Server1: Company Verified
    deactivate DB
    
    Server1 -> Email: Send Approval Email
    activate Email
    note right of Email
      To: company.email
      Subject: "Company Verified - Welcome!"
      Body:
      - Verification success
      - Can now post jobs
      - Platform guidelines
    end note
    Email -> Server1: Email Sent
    deactivate Email
    
    Server1 -> Frontend: Verification Complete
    deactivate Server1
    Frontend -> Admin: "Company Verified Successfully!"
    deactivate Frontend
    destroy Frontend
    
    note right of Admin
      Company can now:
      - Post unlimited jobs
      - Access full features
      - Trusted badge on profile
    end note
end

@enduml
```

**Key Points:**
- **Starts:** Admin reviews pending companies
- **Ends:** Company verified or rejected
- **Alternative Flows:**
  - Admin not authorized
  - Company rejected with reason
  - Email notification sent in both cases
- **Status:** Planned
- **Purpose:** Prevent fraudulent companies

---

## SD17: Monitor AI System Performance

**Use Case:** UC37
**Status:** 🔵 Planned
**Actors:** Admin, Frontend, Server-1, Server-2, Pinecone, OpenAI
**Purpose:** Admin monitors AI service health and performance

```plantuml
@startuml
actor Admin
participant "Frontend\n(Admin Panel)" as Frontend
participant "Server-1\n(Node.js/Express)" as Server1
participant "Server-2\n(FastAPI)" as Server2
database "Pinecone\n(Vector DB)" as Pinecone
participant "OpenAI API" as OpenAI

title SD17: Monitor AI System Performance (Planned)

Admin -> Frontend: 1. Navigate to "AI System Monitoring"
activate Frontend

Frontend -> Server1: 2. GET /api/admin/ai-system/status
activate Server1
note right of Server1
  Headers: Authorization (Admin)
end note

Server1 -> Server1: 3. Verify Admin Token

alt Not Admin
    Server1 -> Frontend: 4a. Unauthorized
    deactivate Server1
    Frontend -> Admin: Access Denied
    deactivate Frontend
else Valid Admin
    == Check Server-2 Health ==
    
    Server1 -> Server2: 4b. GET /health
    activate Server2
    
    Server2 -> Pinecone: 5. Check Pinecone Connection
    activate Pinecone
    note right of Server2
      Query: Get index stats
    end note
    
    alt Pinecone Connection Failed
        Pinecone -> Server2: Connection Error
        deactivate Pinecone
        Server2 -> Server1: Pinecone Unhealthy
        note right of Server2
          Status: "degraded"
          Pinecone: "disconnected"
        end note
    else Pinecone Connected
        Pinecone -> Server2: Index Statistics
        deactivate Pinecone
        note right of Pinecone
          Returns:
          - Total vector count
          - Namespace breakdown
          - Index dimensions
          - Last update time
        end note
    end
    
    Server2 -> Server2: 6. Check OpenAI Status
    note right of Server2
      Verify:
      - API key valid
      - Rate limit status
      - Recent request success rate
    end note
    
    Server2 -> Server1: 7. AI System Health Report
    deactivate Server2
    note right of Server2
      Response: {
        status: "healthy",
        pinecone: {
          connected: true,
          index: "careerkonnekt-jobs",
          total_vectors: 450,
          namespaces: {
            jobs: 300,
            profiles: 150
          },
          dimensions: 1536
        },
        openai: {
          configured: true,
          model: "text-embedding-3-small",
          rate_limit_status: "ok"
        },
        uptime: "15 days, 3 hours",
        last_restart: "2026-01-23"
      }
    end note
    
    == Get Performance Metrics ==
    
    Server1 -> Server2: 8. GET /api/admin/metrics
    activate Server2
    
    Server2 -> Server2: 9. Calculate Metrics
    note right of Server2
      Metrics calculated:
      - Recommendation requests (last 24h)
      - Average response time
      - Success rate
      - Failed requests
      - Top matched jobs
      - User engagement with recommendations
    end note
    
    Server2 -> Server1: Performance Metrics
    deactivate Server2
    note right of Server2
      Response: {
        last_24h: {
          recommendation_requests: 342,
          avg_response_time_ms: 245,
          success_rate: 99.1,
          failed_requests: 3
        },
        last_7d: {
          job_ingestions: 78,
          profile_ingestions: 145,
          recommendations_generated: 2156
        },
        top_matched_jobs: [...],
        average_match_score: 0.76
      }
    end note
    
    Server1 -> Frontend: 10. Complete AI System Status
    deactivate Server1
    note right of Server1
      Combined Response:
      - Health status
      - Pinecone stats
      - OpenAI status
      - Performance metrics
      - Alerts (if any)
    end note
    
    Frontend -> Admin: 11. Display AI System Dashboard
    deactivate Frontend
    destroy Frontend
    
    note right of Admin
      Dashboard displays:
      - Real-time health status
      - Vector database stats
      - API usage & rate limits
      - Performance graphs
      - Recent errors/warnings
      - System recommendations
      
      Admin can:
      - View detailed logs
      - Adjust AI parameters
      - Restart services (if needed)
      - Export metrics reports
    end note
end

@enduml
```

**Key Points:**
- **Starts:** Admin opens AI monitoring dashboard
- **Ends:** Complete system health displayed
- **Alternative Flows:**
  - Pinecone connection failure
  - OpenAI API issues
  - Server-2 unreachable
- **Status:** Planned
- **Purpose:** Proactive monitoring and issue detection

---

# 📐 How to Render These Diagrams <a name="rendering"></a>

## Option 1: Online PlantUML Editor
1. Visit: https://www.plantuml.com/plantuml/uml/
2. Copy any sequence diagram code from above
3. Paste into editor
4. View rendered diagram instantly
5. Export as PNG/SVG

## Option 2: VS Code Extension
1. Install "PlantUML" extension by jebbs
2. Install Graphviz: https://graphviz.org/download/
3. Create `.puml` file with diagram code
4. Press `Alt+D` to preview
5. Right-click → Export

## Option 3: PlantUML CLI
```bash
# Install
npm install -g node-plantuml

# Render
plantuml sequence-diagram.puml -o output.png
```

## Option 4: Draw.io (Manual)
- Import this document as reference
- Use Draw.io UML shapes
- Follow flow described in each diagram

---

# 📝 Diagram Creation Tips

## For Your FYP Presentation:

1. **Select Key Diagrams:**
   - Don't include all 17 diagrams
   - Choose 4-5 most impressive ones:
     - SD3: Profile with AI Sync (shows microservices)
     - SD6: Job Recommendations (full AI flow)
     - SD10: Job Posting with Vectorization
     - SD8: AI Interview (innovative feature)
     - SD16: Admin Verification (governance)

2. **Simplify for Presentation:**
   - Remove less critical alt flows
   - Focus on happy path
   - Highlight AI/ML components in color

3. **Explain Clearly:**
   - Walk through step-by-step
   - Emphasize microservices communication
   - Show where AI adds value

4. **Technical Depth:**
   - These diagrams show implementation-level detail
   - Perfect for technical evaluation
   - Demonstrates understanding of system architecture

---

# 🎓 Summary

This document provides **17 complete sequence diagrams** covering:

## ✅ Implemented Features (9 diagrams):
- SD1: User Registration
- SD2: User Login
- SD3: Profile Management with AI
- SD4: AI Content Enhancement
- SD5: CV Download
- SD6: Job Recommendations (Full AI Flow)
- SD9: Company Registration
- SD10: Job Posting with AI
- SD11: Update Job
- SD12: Delete Job

## 🔵 Planned Features (7 diagrams):
- SD7: Apply for Job
- SD8: AI Interview
- SD13: View Applications
- SD14: Schedule AI Interview
- SD15: Admin Login
- SD16: Verify Company
- SD17: Monitor AI System

Each diagram includes:
- Complete actor-system interactions
- Alternative flows (ALT blocks)
- Error handling
- Lifeline management
- Activation/deactivation
- Notes and explanations

**Ready for FYP evaluation and presentation!** 🚀
