# 🎓 CareerKonnekt Microservices Architecture Guide

## 📚 Table of Contents
1. [What is Microservices Architecture?](#microservices-explained)
2. [Your Project Architecture](#your-architecture)
3. [How Everything Works Together](#how-it-works)
4. [Complete Setup Guide](#setup-guide)
5. [Testing the System](#testing)
6. [API Integration Examples](#api-examples)
7. [Frequently Asked Questions](#faq)

---

## 🏗️ Microservices Explained <a name="microservices-explained"></a>

### What is Microservices Architecture?

Think of your project like a restaurant:

**Monolithic (Old Way):**
- One person cooks, serves, cleans, and manages billing
- If they get sick, the whole restaurant shuts down
- Hard to scale - can't just add more of what you need

**Microservices (Your Project):**
- **Chef (Server-1)**: Handles food preparation (auth, profiles, job posting)
- **Sommelier (Server-2)**: Recommends the perfect wine (AI job matching)
- **Cashier**: Handles payments (could be Server-3 in future)

Each service:
- Works independently
- Has its own database/storage
- Can scale separately
- Can be in different languages

### Why Microservices for CareerKonnekt?

1. **Separation of Concerns**
   - Server-1: Business logic, CRUD operations
   - Server-2: AI/ML computations

2. **Independent Scaling**
   - More users? Scale Server-1
   - More recommendations? Scale Server-2

3. **Technology Freedom**
   - Server-1: Node.js (fast, good for APIs)
   - Server-2: Python (best for AI/ML)

4. **Fault Isolation**
   - If AI service goes down, rest of app still works
   - Jobs still get posted even if recommendations fail

---

## 🎯 Your Project Architecture <a name="your-architecture"></a>

### Visual Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         FRONTEND (Next.js)                       │
│                      http://localhost:3000                       │
└───────────────────┬─────────────────────────────────────────────┘
                    │
                    │ REST API Calls
                    │
┌───────────────────┼─────────────────────────────────────────────┐
│                   ↓                                              │
│            SERVER-1 (Node.js/Express)                            │
│            http://localhost:4000                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  ⚙️  Authentication & Authorization                       │   │
│  │  👤  User Management (Applicants & Companies)            │   │
│  │  📝  Profile Management                                  │   │
│  │  💼  Job Posting & Management                            │   │
│  │  📧  Email Verification                                  │   │
│  └──────────────────────────────────────────────────────────┘   │
│                   │                                              │
│                   │ Stores data in                               │
│                   ↓                                              │
│            MongoDB (Database)                                    │
│            - Users, Jobs, Profiles                               │
└───────────────────┬─────────────────────────────────────────────┘
                    │
                    │ HTTP Requests
                    │ (When job posted or profile updated)
                    │
┌───────────────────┼─────────────────────────────────────────────┐
│                   ↓                                              │
│            SERVER-2 (Python/FastAPI)                             │
│            http://localhost:8000                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  🤖  AI Job Recommendation Engine                        │   │
│  │  📊  Vector Embeddings Generation                        │   │
│  │  🔍  Semantic Search & Matching                          │   │
│  │  📈  Similarity Scoring                                  │   │
│  └──────────────────────────────────────────────────────────┘   │
│                   │                                              │
│                   │ Converts text to vectors & stores            │
│                   ↓                                              │
│            Pinecone (Vector Database)                            │
│            - Job Vectors (namespace: "jobs")                     │
│            - Profile Vectors (namespace: "profiles")             │
│                   │                                              │
│                   ↓                                              │
│            OpenAI API                                            │
│            - Generates embeddings (text → vectors)               │
└─────────────────────────────────────────────────────────────────┘
```

### Tech Stack Summary

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Frontend | Next.js, React | User interface |
| Server-1 | Node.js, Express | Main business logic |
| Server-2 | Python, FastAPI | AI recommendations |
| DB (Server-1) | MongoDB | Store users, jobs, profiles |
| DB (Server-2) | Pinecone | Store vector embeddings |
| AI Service | OpenAI | Generate text embeddings |

---

## 🔄 How Everything Works Together <a name="how-it-works"></a>

### Scenario 1: Company Posts a Job

```
Step 1: Company fills job form in frontend
        ↓
Step 2: Frontend → POST /api/company/jobs (Server-1)
        ↓
Step 3: Server-1 validates data
        ↓
Step 4: Server-1 saves job to MongoDB
        ↓
Step 5: Server-1 → POST /api/jobs/ingest (Server-2)
        Data sent: {
          job_id: "123",
          title: "Senior Developer",
          skills: ["Python", "FastAPI"],
          description: "We are looking for..."
        }
        ↓
Step 6: Server-2 receives job data
        ↓
Step 7: Server-2 converts job to text:
        "Job Title: Senior Developer | Skills: Python, FastAPI | 
         Description: We are looking for..."
        ↓
Step 8: Server-2 → OpenAI API (generate embedding)
        Text → [0.234, -0.567, 0.123, ...] (1536 numbers)
        ↓
Step 9: Server-2 → Pinecone (store vector)
        Stores: {
          id: "job_123",
          vector: [0.234, -0.567, ...],
          metadata: {title, skills, location, etc.}
        }
        ↓
Step 10: Job is now searchable by AI!
```

### Scenario 2: Applicant Creates Profile

```
Step 1: Applicant completes profile form
        ↓
Step 2: Frontend → POST /api/applicant/profile (Server-1)
        ↓
Step 3: Server-1 saves profile to MongoDB
        ↓
Step 4: Server-1 → POST /api/profiles/ingest (Server-2)
        Data sent: {
          applicant_id: "456",
          name: "John Doe",
          skills: ["Python", "React"],
          professional_summary: "5 years of experience..."
        }
        ↓
Step 5: Server-2 converts profile to text
        ↓
Step 6: Server-2 → OpenAI (generate embedding)
        ↓
Step 7: Server-2 → Pinecone (store in "profiles" namespace)
        ↓
Step 8: Profile is ready for matching!
```

### Scenario 3: Applicant Gets Job Recommendations

```
Step 1: Frontend → GET /api/applicant/recommendations (Server-1)
        ↓
Step 2: Server-1 → POST /api/recommendations/ (Server-2)
        Sends: {
          applicant_id: "456",
          top_k: 10,
          filters: {location: "Remote"}
        }
        ↓
Step 3: Server-2 → Pinecone (fetch applicant vector)
        Gets: [0.245, -0.543, 0.134, ...] (applicant's embedding)
        ↓
Step 4: Server-2 → Pinecone (search similar job vectors)
        Pinecone compares applicant vector with all job vectors
        Finds most similar using cosine similarity
        ↓
Step 5: Server-2 enhances results:
        - Adds skill matching score
        - Filters by location
        - Ranks by combined score
        ↓
Step 6: Server-2 returns top 10 matches:
        [
          {
            job_id: "123",
            title: "Senior Developer",
            similarity_score: 0.92,
            matched_skills: ["Python", "FastAPI"],
            company_name: "TechCorp"
          },
          ...
        ]
        ↓
Step 7: Server-1 forwards results to Frontend
        ↓
Step 8: Frontend displays personalized job recommendations!
```

---

## 🚀 Complete Setup Guide <a name="setup-guide"></a>

### Prerequisites Checklist

- ✅ Node.js 18+ installed
- ✅ Python 3.12+ installed
- ✅ MongoDB running (local or Atlas)
- ✅ Git installed

### Step-by-Step Setup

#### Part 1: Get API Keys

1. **Pinecone Account**
   ```
   1. Go to https://www.pinecone.io/
   2. Click "Start for Free"
   3. Sign up with email
   4. After login, click "Create Project"
   5. Go to "API Keys" tab
   6. Copy:
      - API Key
      - Environment (e.g., "us-east-1")
   ```

2. **OpenAI Account**
   ```
   1. Go to https://platform.openai.com/
   2. Click "Sign up"
   3. After login, go to API Keys section
   4. Click "Create new secret key"
   5. Copy the key (starts with sk-...)
   ```

#### Part 2: Setup Server-1 (Node.js Backend)

```bash
# Navigate to Server-1
cd d:/FYP/Code/Backend/Server-1/CareerKonnekt-Backend-Server-1

# Install dependencies
npm install

# Create .env file (if not exists)
# Add this line:
AI_SERVICE_URL=http://localhost:8000

# Start Server-1
node server.js
```

Server-1 should start on **http://localhost:4000**

#### Part 3: Setup Server-2 (Python AI Service)

```bash
# Navigate to Server-2
cd d:/FYP/Code/Backend/Server-2/my_app

# Install uv (Python package manager)
pip install uv

# Install dependencies
uv sync

# Edit .env file
# Add your keys:
OPENAI_API_KEY="sk-your-openai-key-here"
PINECONE_API_KEY="your-pinecone-key-here"
PINECONE_ENVIRONMENT="us-east-1"  # Your Pinecone region
PINECONE_INDEX_NAME="careerkonnekt-jobs"
SERVER1_BASE_URL="http://localhost:4000"

# Start Server-2
python startup.py
```

Server-2 should start on **http://localhost:8000**

#### Part 4: Setup Frontend

```bash
# Navigate to Frontend
cd d:/FYP/Code/Frontend/CareerKonnekt-Frontend

# Install dependencies
npm install

# Edit .env.local
NEXT_PUBLIC_BACKEND_URL="http://localhost:4000"

# Start Frontend
npm run dev
```

Frontend should start on **http://localhost:3000**

---

## ✅ Testing the System <a name="testing"></a>

### Test 1: Check All Services are Running

1. **Server-1**: http://localhost:4000
   - Should see: `{"message": "CareerKonnekt API v2.0 is working"}`

2. **Server-2**: http://localhost:8000
   - Should see: Service info with status "running"

3. **Server-2 Health**: http://localhost:8000/health
   - Should see Pinecone connection status

4. **Frontend**: http://localhost:3000
   - Should see homepage

### Test 2: Complete User Flow

1. **Create Company Account**
   - Go to signup page
   - Register as company
   - Verify email

2. **Post a Job**
   - Login as company
   - Create a job post
   - Fill all details including skills
   - Click "Post Job"
   - ✅ Job saved to MongoDB
   - ✅ Job automatically sent to Server-2
   - ✅ Job converted to vector in Pinecone

3. **Create Applicant Account**
   - Logout, signup as applicant
   - Verify email

4. **Complete Profile**
   - Go to profile page
   - Fill:
     - Personal info
     - Professional summary
     - Skills (similar to job skills)
     - Experience
     - Education
   - Save profile
   - ✅ Profile saved to MongoDB
   - ✅ Profile automatically sent to Server-2
   - ✅ Profile converted to vector in Pinecone

5. **Get Recommendations**
   - Create API call or button to fetch recommendations
   - Call: `GET http://localhost:4000/api/applicant/recommendations`
   - ✅ Should see list of matching jobs!

### Test 3: Verify AI Matching

Check Server-2 logs, you should see:
```
Successfully ingested job 507f1f77bcf86cd799439011 into Pinecone
Successfully ingested profile 507f1f77bcf86cd799439013 into Pinecone
Retrieved 5 job recommendations for applicant 507f1f77bcf86cd799439013
```

---

## 📡 API Integration Examples <a name="api-examples"></a>

### Backend to Backend (Server-1 → Server-2)

These happen automatically, but here's how they work:

```javascript
// In Server-1: After job is created
const aiJobData = {
    job_id: newJob._id.toString(),
    title: "Senior Full Stack Developer",
    company_name: "TechCorp",
    location: "Remote",
    job_type: "Full-time",
    experience_level: "Senior",
    description: "We are looking for...",
    required_skills: ["JavaScript", "React", "Node.js"],
    salary_min: 80000,
    salary_max: 120000,
    is_active: true
};

// Server-1 calls Server-2
await axios.post('http://localhost:8000/api/jobs/ingest', aiJobData);
```

### Frontend to Backend (Next.js → Server-1 → Server-2)

```javascript
// In Frontend: Fetch recommendations
const getRecommendations = async () => {
    const response = await fetch(
        'http://localhost:4000/api/applicant/recommendations?top_k=10',
        {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        }
    );
    
    const data = await response.json();
    console.log(data.recommendations);
    // Returns array of recommended jobs with scores
};
```

---

## ❓ Frequently Asked Questions <a name="faq"></a>

### Q1: What is a vector embedding?

**A:** Think of it like converting text into coordinates on a map.

```
Text: "I love pizza"
Vector: [0.23, -0.45, 0.67, ...] (1536 numbers)

Similar text will have similar vectors:
"I enjoy pizza" → [0.24, -0.44, 0.66, ...]  ← Very close!
"I hate broccoli" → [-0.67, 0.89, -0.23, ...] ← Far away!
```

This allows computers to understand semantic meaning.

### Q2: Why Pinecone instead of regular database?

**Regular Database (MongoDB):**
```sql
SELECT * FROM jobs WHERE title LIKE "%developer%"
```
- Only finds exact text matches
- Misses: "Software Engineer", "Programmer", "Coder"

**Vector Database (Pinecone):**
```python
find_similar(applicant_vector, job_vectors)
```
- Understands meaning
- Finds all related roles automatically
- Scores by similarity

### Q3: Do I need to use AI for a basic version?

You can start simpler:

**Phase 1 (Basic - No AI):**
```javascript
// Simple skill matching
const matchedJobs = jobs.filter(job => {
    const commonSkills = applicant.skills.filter(skill => 
        job.skills.includes(skill)
    );
    return commonSkills.length > 0;
});
```

**Phase 2 (Your Current - AI):**
- Semantic matching with Pinecone
- Understands "React" ≈ "Frontend Development"
- Much more impressive for FYP!

### Q4: What if Server-2 goes down?

The system is designed to handle this:

```javascript
try {
    await ingestJobToAI(jobData);
} catch (error) {
    console.error('AI service unavailable');
    // Job still saved to MongoDB
    // System continues working
}
```

- Core features (auth, job posting) keep working
- Only recommendations temporarily unavailable
- This is the benefit of microservices!

### Q5: How much does this cost?

**Development (Free):**
- Pinecone: Free tier (1M vectors)
- OpenAI: $5 credit for new users
- MongoDB Atlas: Free tier (512MB)

**Your FYP needs:**
- ~100 jobs = ~100 vectors
- ~50 profiles = ~50 vectors
- Total: 150 vectors (well within free tier!)

**API Costs:**
- OpenAI embedding cost: $0.0001 per 1000 tokens
- For 150 profiles + 100 jobs: ~$0.05 total
- Practically free for FYP!

### Q6: Can I deploy this?

Yes! Deployment options:

**Frontend:**
- Vercel (Free)
- Netlify (Free)

**Server-1:**
- Vercel (Free)
- Railway (Free trial)
- Render (Free)

**Server-2:**
- Railway (Best for Python)
- Render (Free tier)
- Google Cloud Run (Pay as you go)

**Databases:**
- MongoDB Atlas (Free 512MB)
- Pinecone (Free tier)

### Q7: How do I explain this in my FYP presentation?

**Simple Explanation:**
"My project uses microservices architecture where Server-1 handles business logic and Server-2 provides AI-powered job recommendations using vector embeddings and semantic search. When a job is posted, it's converted into a mathematical representation that allows us to find similar profiles intelligently, not just by keyword matching."

**Technical Depth:**
"I'm using Pinecone vector database with OpenAI's text-embedding-3-small model to generate 1536-dimensional embeddings. The recommendation engine uses cosine similarity to match applicant profiles with job postings in a multi-dimensional vector space, combined with direct skill matching for enhanced accuracy."

---

## 🎯 Next Steps

1. **Test Everything**: Follow the testing guide above
2. **Add Frontend Integration**: Create UI to display recommendations
3. **Enhance Matching**: Add more filters (salary, location radius)
4. **Add Analytics**: Track which recommendations users apply to
5. **Document Everything**: Keep notes for FYP report

---

## 📞 Support

If something doesn't work:

1. Check all services are running (4000, 8000, 3000)
2. Verify API keys in .env files
3. Check server logs for errors
4. Test each API endpoint individually
5. Check Pinecone dashboard for vector counts

---

**Congratulations!** You now have a production-grade microservices architecture with AI-powered recommendations. This is impressive for a final year project! 🎓🚀
