import userModel from "../models/userModel.js";

export const getUserData = async (req, res) => {
    try {
        const userId = req.userId;

        console.log("userId from req:", req.userId); // 🔍 Check this

        if (!userId) {
            return res.json({ success: false, message: "User ID not found in request" });
        }

        const user = await userModel.findById(userId);

        if (!user) {
            return res.json({ success: false, message: "User not found" })
        }

        res.json({
            success: true,
            userData: {
                name: user.name,
                isAccountVerified: user.isAccountVerified
            }
        })
    } catch (error) {
        return res.json({ success: false, message: error.message })
    }
}

export const deleteUser = async (req, res) => {
    try {
        const userId = req.userId;
        if (!userId) {
            return res.json({ success: false, message: "User ID not found in request" });
        }
        const deletedUser = await userModel.findByIdAndDelete(userId);
        if (!deletedUser) {
            return res.json({ success: false, message: "User not found or already deleted" });
        }
        res.clearCookie('token');
        return res.json({ success: true, message: "Account deleted successfully." });
    } catch (error) {
        return res.json({ success: false, message: error.message });
    }
}
