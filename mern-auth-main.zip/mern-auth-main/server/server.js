import 'dotenv/config';
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import connectDB from "./config/mongodb.js";
import authRouter from './routes/authRoutes.js';
import userRouter from './routes/userRoutes.js';

const app = express();
const port = process.env.PORT || 4000;
connectDB();

// ✅ CORS setup (at the top)
const allowedOrigins = [
    'http://localhost:5173',
    'https://mern-auth-ebon-nu.vercel.app/',
];

app.use(cors({ origin: allowedOrigins, credentials: true }));
// app.options('*', cors({ origin: allowedOrigins, credentials: true }));

// ✅ Manually set CORS headers (must be before routes)
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "https://mern-auth-ebon-nu.vercel.app");
  res.header("Access-Control-Allow-Credentials", "true");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  next();
});

// ✅ Other middlewares
app.use(express.json());
app.use(cookieParser());

// ✅ API Routes
app.get('/', (req, res) => res.json('API working'));
app.use('/api/auth', authRouter);
app.use('/api/user', userRouter);

// ✅ Start Server
app.listen(port, () => console.log(`server started on PORT :${port}`));
