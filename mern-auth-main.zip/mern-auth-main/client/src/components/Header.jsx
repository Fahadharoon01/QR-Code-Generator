import React, { useContext } from 'react'
import { assets } from '../assets/assets'
import { AppContext } from '../context/AppContext'

const Header = () => {

    const { userData } = useContext(AppContext);


    return (
        <div className='flex flex-col items-center mt-10 sm:mt-20 px-2 sm:px-4 text-center text-gray-800 w-full'>
            <img src={assets.header_img} className='w-24 h-24 sm:w-36 sm:h-36 rounded-full mb-4 sm:mb-6' alt="" />
            <h1 className='flex items-center gap-2 text-lg sm:text-3xl font-medium mb-1 sm:mb-2'>Hey {userData ? userData.name : "Developer"}! <img className='w-6 sm:w-8 aspect-square' src={assets.hand_wave} alt="" /></h1>
            <h2 className='text-2xl sm:text-5xl font-semibold mb-2 sm:mb-4'>Welcome to our app</h2>
            <p className='mb-6 sm:mb-8 max-w-xs sm:max-w-md text-xs sm:text-base'>Let's start with a quick product tour and we will have you up and runing in no time!</p>
            <button className='border border-gray-500 rounded-full px-6 sm:px-8 py-2 sm:py-2.5 hover:bg-gray-100 transition-all text-xs sm:text-base'>Get Started</button>
        </div>
    )
}

export default Header