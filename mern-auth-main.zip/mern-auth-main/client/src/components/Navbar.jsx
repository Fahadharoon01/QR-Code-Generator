import React, { useContext, useState } from 'react'
import { assets } from '../assets/assets';
import { useNavigate } from "react-router-dom";
import { AppContext } from '../context/AppContext';
import axios from "axios"
import { toast } from 'react-toastify';
import Swal from 'sweetalert2';

const Navbar = () => {

    const navigate = useNavigate();
    const { userData, backendUrl, setUserData, setIsLoggedIn } = useContext(AppContext);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

    const sendVerificationOtp = async () => {
        try {
            axios.defaults.withCredentials = true;
            const { data } = await axios.post(backendUrl + 'api/auth/send-verify-otp')

            if (data.success) {
                navigate('/email-verify')
                toast.success(data.message);
            } else {
                toast.error(data.message);
            }
        } catch (error) {
            toast.error(error.message)
        }
    }

    const logout = async () => {
        const result = await Swal.fire({
            title: 'Are you sure you want to logout?',
            text: 'You will be logged out of your account.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#6366f1',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, logout',
            background: '#1e293b',
            color: '#a5b4fc',
        });
        if (!result.isConfirmed) return;
        try {
            axios.defaults.withCredentials = true;
            const { data } = await axios.post(backendUrl + 'api/auth/logout');
            if (data.success) {
                setIsLoggedIn(false);
                setUserData(false);
                toast.success('Logged out successfully!');
                navigate('/');
            }
        } catch (error) {
            toast.error(error.message)
        }
    }

    const deleteAccount = async () => {
        const result = await Swal.fire({
            title: 'Delete Account?',
            text: 'Are you sure you want to delete your account? This action cannot be undone.',
            icon: 'error',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6366f1',
            confirmButtonText: 'Yes, delete it',
            background: '#1e293b',
            color: '#a5b4fc',
        });
        if (!result.isConfirmed) return;
        try {
            axios.defaults.withCredentials = true;
            const { data } = await axios.delete(backendUrl + 'api/user/delete');
            if (data.success) {
                setIsLoggedIn(false);
                setUserData(false);
                toast.success('Account deleted successfully!');
                navigate('/login');
            } else {
                toast.error(data.message);
            }
        } catch (error) {
            toast.error(error.message);
        }
    }

    return (
        <nav className='w-full flex items-center justify-between p-4 sm:p-6 sm:px-24 absolute top-0 z-20 bg-white/80 backdrop-blur-md'>
            <img src={assets.logo} className='w-24 sm:w-32 cursor-pointer' alt="" onClick={() => navigate('/')} />
            {/* Desktop Menu */}
            <div className='hidden sm:flex items-center gap-4'>
                {userData ? (
                    <div className='w-8 h-8 flex justify-center items-center rounded-full bg-black text-white relative group'>
                        {userData.name[0].toUpperCase()}
                        <div className='absolute hidden group-hover:block top-0 right-0 z-10 text-black rounded pt-10'>
                            <ul className='list-none m-0 p-2 bg-gray-100 text-sm'>
                                {!userData.isAccountVerified && <li onClick={sendVerificationOtp} className='py-1 px-2 hover:bg-gray-200 cursor-pointer'>Verify email</li>}
                                <li onClick={logout} className='py-1 px-2 hover:bg-gray-200 cursor-pointer pr-10'>Logout</li>
                                <hr className='my-2 border-slate-300' />
                                <li onClick={deleteAccount} className='py-1 px-2 hover:bg-red-200 text-red-600 cursor-pointer'>Delete Account</li>
                            </ul>
                        </div>
                    </div>
                ) : (
                    <button onClick={() => navigate('login')} className='flex items-center gap-2 border border-gray-500 rounded-full px-6 py-2 text-gray-800 hover:bg-gray-100 transition-all'>Login <img src={assets.arrow_icon} alt="" /></button>
                )}
            </div>
            {/* Hamburger Icon for Mobile */}
            <div className='sm:hidden flex items-center'>
                <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className='focus:outline-none'>
                    <svg className='w-8 h-8 text-gray-800' fill='none' stroke='currentColor' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'>
                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d={mobileMenuOpen ? 'M6 18L18 6M6 6l12 12' : 'M4 6h16M4 12h16M4 18h16'} />
                    </svg>
                </button>
            </div>
            {/* Mobile Menu */}
            {mobileMenuOpen && (
                <div className='absolute top-16 left-0 w-full bg-white shadow-lg flex flex-col items-center gap-4 py-4 sm:hidden z-30 animate-fade-in'>
                    {userData ? (
                        <>
                            <div className='w-10 h-10 flex justify-center items-center rounded-full bg-black text-white mb-2'>
                                {userData.name[0].toUpperCase()}
                            </div>
                            {!userData.isAccountVerified && <button onClick={() => { sendVerificationOtp(); setMobileMenuOpen(false); }} className='py-2 px-4 w-11/12 rounded bg-gray-200 text-gray-800 mb-1'>Verify email</button>}
                            <button onClick={() => { logout(); setMobileMenuOpen(false); }} className='py-2 px-4 w-11/12 rounded bg-gray-200 text-gray-800 mb-1'>Logout</button>
                            <button onClick={() => { deleteAccount(); setMobileMenuOpen(false); }} className='py-2 px-4 w-11/12 rounded bg-red-200 text-red-600'>Delete Account</button>
                        </>
                    ) : (
                        <button onClick={() => { navigate('/login'); setMobileMenuOpen(false); }} className='flex items-center gap-2 border border-gray-500 rounded-full px-6 py-2 text-gray-800 hover:bg-gray-100 transition-all w-11/12'>Login <img src={assets.arrow_icon} alt="" /></button>
                    )}
                </div>
            )}
        </nav>
    )
}

export default Navbar
