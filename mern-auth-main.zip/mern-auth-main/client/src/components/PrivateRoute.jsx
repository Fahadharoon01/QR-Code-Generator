// import { useContext } from "react";
// import { AppContext } from "../context/AppContext";
// import { Navigate } from "react-router-dom";

// const PrivateRoute = ({ children }) => {
//   const { isLoggedIn } = useContext(AppContext);
//   if (isLoggedIn === false) {
//     return <Navigate to="/login" replace />;
//   }
//   return children;
// };

// export default PrivateRoute; 
