import React, { useContext, useEffect } from 'react'
import { assets } from '../assets/assets'
import { AppContext } from '../context/AppContext'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import Swal from 'sweetalert2';

const VerifyEmail = () => {

  axios.defaults.withCredentials = true;
  const { backendUrl, isLoggedIn, userData, getUserData, setIsLoggedIn, setUserData } = useContext(AppContext)

  const navigate = useNavigate();

  const inputRef = React.useRef([])

  const handleInput = (e, index) => {
    if (e.target.value.length > 0 && index < inputRef.current.length - 1) {
      inputRef.current[index + 1].focus();
    }
  }

  const handleKeyDown = (e, index) => {
    if (e.key === 'Backspace' && e.target.value === '' && index > 0) {
      inputRef.current[index - 1].focus();
    }
  }

  const handlePaste = (e) => {
    const paste = e.clipboardData.getData('text')
    const pasteArray = paste.split('')
    pasteArray.forEach((char, index) => {
      if (inputRef.current[index]) {
        inputRef.current[index].value = char
      }
    })
  }

  const onSubmitHandler = async (e) => {
    try {
      e.preventDefault();
      const otpArray = inputRef.current.map(e => e.value);
      const otp = otpArray.join('')

      const { data } = await axios.post(backendUrl + 'api/auth/verify-account', { otp })

      if (data.success) {
        toast.success(data.message)
        getUserData()
        navigate('/')
      } else {
        toast.error(data.message)
      }
    } catch (error) {
      toast.error(error.message)
    }
  }

  const deleteAccount = async () => {
    const result = await Swal.fire({
      title: 'Delete Account?',
      text: 'Are you sure you want to delete your account? This action cannot be undone.',
      icon: 'error',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#6366f1',
      confirmButtonText: 'Yes, delete it',
      background: '#1e293b',
      color: '#a5b4fc',
    });
    if (!result.isConfirmed) return;
    try {
      axios.defaults.withCredentials = true;
      const { data } = await axios.delete(backendUrl + 'api/user/delete');
      if (data.success) {
        setIsLoggedIn(false);
        setUserData(false);
        toast.success('Account deleted successfully!');
        navigate('/login');
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      toast.error(error.message);
    }
  }

  useEffect(() => {
    isLoggedIn && userData && userData.isAccountVerified && navigate('/')
  }, [isLoggedIn, userData])

  // Handle blank page and redirect if already verified
  if (!userData) {
    return <div className='flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-200 to-purple-400 text-white text-xl'>Loading...</div>;
  }
  if (isLoggedIn && userData.isAccountVerified) {
    navigate(-1); // Go back to previous page
    return null;
  }


  return (
    <div className='flex items-center justify-center min-h-screen px-2 sm:px-0 bg-gradient-to-br from-blue-200 to-purple-400'>
      <img onClick={() => navigate('/')} src={assets.logo} className='absolute left-3 sm:left-20 top-3 w-20 sm:w-32 cursor-pointer' alt="" />
      <form onSubmit={onSubmitHandler} className='bg-slate-900 p-4 sm:p-8 rounded-lg shadow-lg w-full max-w-xs sm:max-w-md text-sm'>
        <h1 className='text-white text-xl sm:text-2xl font-semibold text-center mb-4'>Email Verify OTP</h1>
        <p className='text-center mb-6 text-indigo-300 text-xs sm:text-sm'>Enter the 6-digit code sent to your email id.</p>
        <div className='flex justify-between mb-8' onPaste={handlePaste}>
          {
            Array(6).fill(0).map((_, index) => {
              return <input ref={e => inputRef.current[index] = e} onInput={(e) => handleInput(e, index)} onKeyDown={(e => handleKeyDown(e, index))} type="text" key={index} className="w-8 h-8 sm:w-12 sm:h-12 bg-[#333A5C] text-white text-center text-lg sm:text-xl rounded-md" maxLength="1" required />
            })
          }
        </div>
        <button className='w-full py-2 bg-gradient-to-r from-indigo-500 to-indigo-900 text-white rounded-full text-xs sm:text-base'>Verify email</button>
        <hr className='my-4 border-slate-700' />
        <button type='button' onClick={deleteAccount} className='w-full py-2 bg-gradient-to-r from-red-500 to-red-900 text-white rounded-full mt-2 hover:bg-red-700 transition-all text-xs sm:text-base'>Delete Account</button>
      </form>
    </div>
  )
}

export default VerifyEmail