import React, { useContext, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import { assets } from '../assets/assets';
import { AppContext } from '../context/AppContext';

const ResetPassword = () => {
  const { backendUrl } = useContext(AppContext);
  axios.defaults.withCredentials = true;

  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [isEmailSent, setIsEmailSent] = useState(false); // Changed initial state to boolean
  const [otp, setOtp] = useState(''); // Changed initial state to empty string for OTP
  const [isOtpSubmitted, setIsOtpSubmitted] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Using useRef for input elements for OTP
  const inputRefs = useRef([]);

  // Function to move focus to the next OTP input field
  const handleInput = (e, index) => {
    if (e.target.value.length > 0 && index < inputRefs.current.length - 1) {
      inputRefs.current[index + 1].focus();
    }
  };

  // Function to move focus to the previous OTP input field on backspace
  const handleKeyDown = (e, index) => {
    if (e.key === 'Backspace' && e.target.value === '' && index > 0) {
      inputRefs.current[index - 1].focus();
    }
  };

  // Function to handle pasting OTP into the input fields
  const handlePaste = (e) => {
    e.preventDefault(); // Prevent default paste behavior
    const paste = e.clipboardData.getData('text');
    const pasteArray = paste.split('');
    pasteArray.forEach((char, index) => {
      if (inputRefs.current[index]) {
        inputRefs.current[index].value = char;
        // Move focus to the next input after pasting
        if (index < inputRefs.current.length - 1) {
          inputRefs.current[index + 1].focus();
        }
      }
    });
    // Manually trigger the OTP submission logic after paste
    const otpArray = inputRefs.current.map(input => input ? input.value : '');
    setOtp(otpArray.join(''));
  };

  // Handles submitting the email to send OTP
  const onSubmitEmail = async (e) => {
    e.preventDefault();
    try {
      const { data } = await axios.post(backendUrl + 'api/auth/send-reset-otp', { email });

      if (data.success) {
        toast.success(data.message);
        setIsEmailSent(true);
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      console.error("Error sending reset OTP email:", error);
      toast.error(error.response?.data?.message || "Failed to send OTP. Please try again.");
    }
  };

  // Handles submitting the OTP
  const onSubmitOtp = async (e) => {
    e.preventDefault();
    const otpArray = inputRefs.current.map(input => input ? input.value : '');
    const enteredOtp = otpArray.join('');
    setOtp(enteredOtp); // Set the OTP state
    setIsOtpSubmitted(true); // Move to the new password form
  };

  // Handles submitting the new password
  const onSubmitNewPassword = async (e) => {
    e.preventDefault();
    // Log the values being sent to the backend for debugging
    console.log("Submitting new password with:");
    console.log("Email:", email);
    console.log("OTP:", otp);
    console.log("Password:", newPassword);

    // Basic client-side validation for password
    if (!newPassword || newPassword.length < 6) { // Example: password must be at least 6 characters
      toast.error("Password must be at least 6 characters long.");
      return;
    }

    try {
      const { data } = await axios.post(backendUrl + 'api/auth/reset-password', { email, otp, newPassword });

      if (data.success) {
        toast.success(data.message);
        navigate('/login');
      } else {
        toast.error(data.message);
      }
    } catch (error) {
      console.error("Error resetting password:", error);
      toast.error(error.response?.data?.message || "Failed to reset password. Please try again.");
    }
  };

  return (
    <div className='flex items-center justify-center min-h-screen px-2 sm:px-0 bg-gradient-to-br from-blue-200 to-purple-400'>
      {/* Logo for navigation */}
      <img onClick={() => navigate('/')} src={assets.logo} className='absolute left-3 sm:left-20 top-3 w-20 sm:w-32 cursor-pointer' alt="Logo" />

      {/* Enter Email ID Form */}
      {!isEmailSent && (
        <form onSubmit={onSubmitEmail} className='bg-slate-900 p-4 sm:p-8 rounded-lg shadow-lg w-full max-w-xs sm:max-w-md text-sm'>
          <h1 className='text-white text-xl sm:text-2xl font-semibold text-center mb-4'>Reset Password</h1>
          <p className='text-center mb-6 text-indigo-300 text-xs sm:text-sm'>Enter your registered email address</p>
          <div className='mb-4 flex items-center gap-3 w-full px-4 py-2 rounded-full bg-[#333A5C]'>
            <img src={assets.mail_icon} alt="Mail icon" className='w-4 h-4' />
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              type="email"
              placeholder='Email id'
              className='bg-transparent outline-none text-white w-full text-xs sm:text-sm'
            />
          </div>
          <button type="submit" className='w-full py-2 bg-gradient-to-r from-indigo-500 to-indigo-900 text-white rounded-full mt-3 text-xs sm:text-base'>Submit</button>
        </form>
      )}

      {/* OTP Input Form */}
      {!isOtpSubmitted && isEmailSent && (
        <form onSubmit={onSubmitOtp} className='bg-slate-900 p-4 sm:p-8 rounded-lg shadow-lg w-full max-w-xs sm:max-w-md text-sm'>
          <h1 className='text-white text-xl sm:text-2xl font-semibold text-center mb-4'>Reset Password OTP</h1>
          <p className='text-center mb-6 text-indigo-300 text-xs sm:text-sm'>Enter the 6-digit code sent to your email id.</p>
          <div className='flex justify-between mb-8' onPaste={handlePaste}>
            {Array(6).fill(0).map((_, index) => (
              <input
                key={index}
                ref={el => inputRefs.current[index] = el}
                onInput={(e) => handleInput(e, index)}
                onKeyDown={(e) => handleKeyDown(e, index)}
                type="text"
                className="w-8 h-8 sm:w-12 sm:h-12 bg-[#333A5C] text-white text-center text-lg sm:text-xl rounded-md"
                maxLength="1"
                required
              />
            ))}
          </div>
          <button type="submit" className='w-full py-2 bg-gradient-to-r from-indigo-500 to-indigo-900 text-white rounded-full text-xs sm:text-base'>Submit</button>
        </form>
      )}

      {/* Enter New Password Form */}
      {isOtpSubmitted && isEmailSent && (
        <form onSubmit={onSubmitNewPassword} className='bg-slate-900 p-4 sm:p-8 rounded-lg shadow-lg w-full max-w-xs sm:max-w-md text-sm'>
          <h1 className='text-white text-xl sm:text-2xl font-semibold text-center mb-4'>New Password</h1>
          <p className='text-center mb-6 text-indigo-300 text-xs sm:text-sm'>Enter the new password below</p>
          <div className='mb-4 flex items-center gap-3 w-full px-4 py-2 rounded-full bg-[#333A5C]'>
            <img src={assets.lock_icon} alt="Lock icon" className='w-4 h-4' />
            <input
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              type={showPassword ? 'text' : 'password'}
              placeholder='New Password'
              className='bg-transparent outline-none text-white w-full text-xs sm:text-sm'
              required
            />
            <img
              src={showPassword ? assets.eye_off_icon : assets.eye_icon}
              alt={showPassword ? 'Hide password' : 'Show password'}
              className='cursor-pointer w-5 h-5'
              onClick={() => setShowPassword((prev) => !prev)}
              title={showPassword ? 'Hide password' : 'Show password'}
            />
          </div>
          <button type="submit" className='w-full py-2 bg-gradient-to-r from-indigo-500 to-indigo-900 text-white rounded-full mt-3 text-xs sm:text-base'>Submit</button>
        </form>
      )}
    </div>
  );
};

export default ResetPassword;
