import { useContext, useState } from 'react'
import { assets } from '../assets/assets';
import { useNavigate } from 'react-router-dom';
import { AppContext } from '../context/AppContext';
import axios from "axios";
import { toast } from 'react-toastify';

const Login = () => {
  const navigate = useNavigate();
  const { backendUrl, setIsLoggedIn, getUserData } = useContext(AppContext);

  const [state, setState] = useState('Sign Up');
  const [name, setName] = useState('');
  const [email, setEmail] = useState(''); // Correctly bind to email
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const onSubmitHandler = async (e) => {
    try {
      e.preventDefault();
      axios.defaults.withCredentials = true;

      if (state === 'Sign Up') {
        const { data } = await axios.post(backendUrl + "api/auth/register", {
          name, email, password
        });

        if (data.success) {
          setIsLoggedIn(true);
          getUserData();
          toast.success('Account created successfully!');
          navigate('/');
        } else {
          toast.error(data.message);
        }
      } else { // Login state
        const { data } = await axios.post(backendUrl + "api/auth/login", {
          email, password
        });

        if (data.success) {
          setIsLoggedIn(true);
          getUserData();
          toast.success('Logged in successfully!');
          navigate('/');
        } else {
          toast.error(data.message);
        }
      }
    } catch (error) {
      toast.error(error.message);
    }
  };

  return (
    <div className='flex items-center justify-center min-h-screen px-2 sm:px-0 bg-gradient-to-br from-blue-200 to-purple-400'>
      <img onClick={() => navigate('/')} src={assets.logo} className='absolute left-3 sm:left-20 top-3 w-20 sm:w-32 cursor-pointer' alt="" />
      <div className='bg-slate-900 p-4 sm:p-10 rounded-lg shadow-lg w-full max-w-xs sm:max-w-md text-indigo-300 text-sm'>
        <h2 className='text-2xl sm:text-3xl font-semibold text-white text-center mb-3'>{state === 'Sign Up' ? 'Create Account' : 'Login'}</h2>
        <p className='text-center text-xs sm:text-sm mb-6'>{state === 'Sign Up' ? 'Create your account' : 'Login to your account!'}</p>

        <form onSubmit={onSubmitHandler}>
          {/* Conditional rendering for Name input (only for Sign Up) */}
          {state === 'Sign Up' && (
            <div className='mb-4 flex items-center gap-3 w-full px-4 py-2 rounded-full bg-[#333A5C]'>
              <img src={assets.person_icon} alt="" className='w-4 h-4' />
              <input
                onChange={e => setName(e.target.value)}
                value={name}
                className='bg-transparent outline-none w-full text-xs sm:text-sm'
                type="text"
                placeholder='Full Name'
                required={state === 'Sign Up'}
              />
            </div>
          )}

          {/* Email Input */}
          <div className='mb-4 flex items-center gap-3 w-full px-4 py-2 rounded-full bg-[#333A5C]'>
            <img src={assets.mail_icon} alt="" className='w-4 h-4' />
            <input
              onChange={e => setEmail(e.target.value)}
              value={email}
              className='bg-transparent outline-none w-full text-xs sm:text-sm'
              type="email"
              placeholder='Email id'
              required
            />
          </div>

          {/* Password Input */}
          <div className='mb-4 flex items-center gap-3 w-full px-4 py-2 rounded-full bg-[#333A5C]'>
            <img src={assets.lock_icon} alt="" className='w-4 h-4' />
            <input
              onChange={e => setPassword(e.target.value)}
              value={password}
              className='bg-transparent outline-none flex-1 w-full text-xs sm:text-sm'
              type={showPassword ? 'text' : 'password'}
              placeholder='Password'
              required
            />
            <img
              src={showPassword ? assets.eye_off_icon : assets.eye_icon}
              alt={showPassword ? 'Hide password' : 'Show password'}
              className='cursor-pointer w-5 h-5'
              onClick={() => setShowPassword((prev) => !prev)}
              title={showPassword ? 'Hide password' : 'Show password'}
            />
          </div>

          <p onClick={() => navigate('/reset-password')} className='mb-4 text-indigo-500 cursor-pointer text-xs sm:text-sm' >Forgot password?</p>
          <button className='w-full py-2 rounded-full bg-gradient-to-r from-indigo-500 to-indigo-900 text-white font-medium cursor-pointer text-xs sm:text-base'>{state}</button>
        </form>

        {state === 'Sign Up' ? (
          <p className='text-gray-400 text-center text-xs mt-4'>Already have an account?{' '}
            <span onClick={() => setState('Login')} className='text-blue-400 cursor-pointer underline'>Login here</span>
          </p>
        ) : (
          <p className='text-gray-400 text-center text-xs mt-4'>Don't have an account?{' '}
            <span onClick={() => setState('Sign Up')} className='text-blue-400 cursor-pointer underline'>Sign Up</span>
          </p>
        )}
      </div>
    </div>
  );
};

export default Login;
