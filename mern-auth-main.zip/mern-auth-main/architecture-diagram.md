# 🏗️ CareerKonnekt - Complete System Architecture Diagram

## 📋 Overview
This document contains the complete system architecture diagram for CareerKonnekt - an AI-powered job recommendation platform using microservices architecture.

---

# 🎯 Complete System Architecture

## PlantUML Code (Main Architecture)

```plantuml
@startuml CareerKonnekt_Architecture

!define RECTANGLE class

skinparam rectangle {
    BackgroundColor<<frontend>> #E3F2FD
    BackgroundColor<<backend>> #C8E6C9
    BackgroundColor<<ai>> #FFE0B2
    BackgroundColor<<database>> #F8BBD0
    BackgroundColor<<external>> #D1C4E9
    BorderColor Black
    FontSize 12
}

skinparam cloud {
    BackgroundColor #FFF9C4
    BorderColor Black
}

skinparam database {
    BackgroundColor #FFCCBC
    BorderColor Black
}

skinparam component {
    BackgroundColor #B2DFDB
    BorderColor Black
}

title CareerKonnekt - Microservices Architecture with AI Integration

' ============================================
' USER LAYER
' ============================================

actor "Applicant\n(Job Seeker)" as Applicant #LightBlue
actor "Company\n(Recruiter)" as Company #LightGreen
actor "Admin\n(Platform Manager)" as Admin #LightCoral

' ============================================
' PRESENTATION LAYER - FRONTEND
' ============================================

package "Frontend Layer\n(Presentation Tier)" <<frontend>> {
    
    rectangle "Next.js Application\n(Port 3000/3001)" as NextJS {
        component "Landing Pages" as Landing {
            [Home Page]
            [About]
            [Features]
        }
        
        component "Authentication" as FrontendAuth {
            [Sign Up]
            [Sign In]
            [Email Verification]
            [Password Reset]
        }
        
        component "Applicant Dashboard" as ApplicantUI {
            [Profile Management]
            [Job Recommendations]
            [CV Download]
            [AI Enhancement]
            [Job Search]
            [Applications Tracking]
        }
        
        component "Company Dashboard" as CompanyUI {
            [Job Posting]
            [Applications Management]
            [Candidate View]
            [AI Interview Setup]
        }
        
        component "Admin Panel" as AdminUI {
            [User Management]
            [Company Verification]
            [System Monitoring]
            [AI Metrics Dashboard]
        }
    }
    
    component "State Management" as StateManagement {
        [Context API]
        [Cookie Manager]
        [Token Manager]
    }
    
    component "API Client" as APIClient {
        [Axios/Fetch]
        [JWT Interceptors]
        [Error Handlers]
    }
}

' ============================================
' APPLICATION LAYER - BACKEND SERVICES
' ============================================

package "Backend Layer\n(Business Logic Tier)" <<backend>> {
    
    ' ---------- SERVER-1 (Main Backend) ----------
    rectangle "Server-1\nNode.js/Express\n(Port 4000)" as Server1 {
        
        component "API Gateway\n& Router" as Router {
            [Auth Routes]
            [Applicant Routes]
            [Company Routes]
            [Admin Routes]
        }
        
        component "Controllers" as Controllers {
            rectangle "Auth Controllers" as AuthCtrl {
                [Login/Register]
                [Email Verification]
                [Password Management]
            }
            
            rectangle "Applicant Controllers" as ApplicantCtrl {
                [Profile CRUD]
                [CV Generation]
                [Recommendation Gateway]
            }
            
            rectangle "Company Controllers" as CompanyCtrl {
                [Job Post CRUD]
                [Application Management]
                [Candidate Filtering]
            }
            
            rectangle "Admin Controllers" as AdminCtrl {
                [User Management]
                [Verification]
                [Analytics]
            }
        }
        
        component "Middlewares" as Middleware {
            [JWT Authentication]
            [Role Authorization]
            [Profile Completion Check]
            [Input Validation]
            [Error Handler]
        }
        
        component "Services" as Services1 {
            [AI Recommendation Service]
            [Email Service]
            [PDF Generator Service]
            [Cloudinary Service]
            [Gemini AI Service]
        }
        
        component "Models (Mongoose)" as Models {
            [User Model]
            [Applicant Model]
            [Company Model]
            [Profile Model]
            [JobPost Model]
            [Application Model]
        }
        
        component "Utils" as Utils {
            [JWT Helper]
            [Bcrypt Helper]
            [Validators]
            [CV Templates]
        }
    }
    
    ' ---------- SERVER-2 (AI Service) ----------
    rectangle "Server-2\nFastAPI/Python\n(Port 8000)" as Server2 <<ai>> {
        
        component "FastAPI App" as FastAPI {
            [CORS Middleware]
            [Health Check]
            [Error Handlers]
        }
        
        component "API Routes" as AIRoutes {
            [/api/jobs/ingest]
            [/api/jobs/update]
            [/api/jobs/delete]
            [/api/profiles/ingest]
            [/api/profiles/delete]
            [/api/recommendations/]
        }
        
        component "AI Services" as AIServices {
            rectangle "Job Service" as JobService {
                [Ingest Job]
                [Update Job]
                [Delete Job]
                [Search Similar Jobs]
            }
            
            rectangle "Profile Service" as ProfileService {
                [Ingest Profile]
                [Update Profile]
                [Delete Profile]
                [Get Job Recommendations]
            }
            
            rectangle "Matching Engine" as MatchingEngine {
                [Vector Similarity]
                [Skill Matching]
                [Score Calculation]
                [Ranking Algorithm]
            }
        }
        
        component "Utilities" as AIUtils {
            [Embedding Generator]
            [Text Preprocessor]
            [Metadata Extractor]
        }
        
        component "Configuration" as AIConfig {
            [Settings (Pydantic)]
            [Pinecone Manager]
            [OpenAI Config]
        }
    }
}

' ============================================
' DATA LAYER - DATABASES
' ============================================

package "Data Layer\n(Persistence Tier)" <<database>> {
    
    database "MongoDB\n(Primary Database)" as MongoDB {
        frame "Collections" {
            component "users" as UsersCol {
                note right
                  - email
                  - password (hashed)
                  - role
                  - is_verified
                end note
            }
            component "applicants" as ApplicantsCol {
                note right
                  - user_id
                  - profile data
                  - skills
                  - experience
                end note
            }
            component "companies" as CompaniesCol {
                note right
                  - user_id
                  - company_name
                  - industry
                  - location
                end note
            }
            component "profiles" as ProfilesCol {
                note right
                  - applicant_id
                  - resume details
                  - cv template
                  - isProfileCompleted
                end note
            }
            component "jobposts" as JobPostsCol {
                note right
                  - company_id
                  - job details
                  - requirements
                  - status
                  - is_deleted
                end note
            }
            component "applications" as ApplicationsCol {
                note right
                  - job_id
                  - applicant_id
                  - status
                  - applied_at
                end note
            }
        }
    }
    
    database "Pinecone\n(Vector Database)" as Pinecone <<ai>> {
        frame "Index: careerkonnekt-jobs" {
            component "Namespace: jobs" as JobsNamespace {
                note right
                  - Vector ID: job_{id}
                  - Embedding: 1536 dims
                  - Metadata: job details
                end note
            }
            component "Namespace: profiles" as ProfilesNamespace {
                note right
                  - Vector ID: profile_{id}
                  - Embedding: 1536 dims
                  - Metadata: profile details
                end note
            }
        }
        
        component "ServerlessSpec" as PineconeSpec {
            note right
              - Cloud: AWS
              - Region: us-east-1
              - Metric: cosine
            end note
        }
    }
}

' ============================================
' EXTERNAL SERVICES LAYER
' ============================================

package "External Services\n(Third-Party Integrations)" <<external>> {
    
    cloud "OpenAI API" as OpenAI {
        component "Embeddings" as OpenAIEmbed {
            [Model: text-embedding-3-small]
            [Dimensions: 1536]
            [Input: Job/Profile text]
            [Output: Vector array]
        }
        
        component "GPT (Planned)" as OpenAIGPT {
            [AI Interview Questions]
            [Answer Evaluation]
            [Insights Generation]
        }
    }
    
    cloud "Google Gemini AI" as Gemini {
        component "Content Enhancement" as GeminiService {
            [Profile Summary Enhancement]
            [Experience Description]
            [Project Description]
            [Professional Language]
        }
    }
    
    cloud "Cloudinary" as Cloudinary {
        component "Media Storage" as CloudinaryService {
            [Profile Pictures]
            [Company Logos]
            [Document Uploads]
            [Image Optimization]
        }
    }
    
    cloud "NodeMailer\n(SMTP)" as NodeMailer {
        component "Email Service" as EmailService {
            [OTP Verification]
            [Password Reset]
            [Application Notifications]
            [Interview Invitations]
        }
    }
}

' ============================================
' CONNECTIONS - USER TO FRONTEND
' ============================================

Applicant -down-> Landing : Browse
Applicant -down-> FrontendAuth : Sign Up/In
Applicant -down-> ApplicantUI : Use Dashboard
Company -down-> FrontendAuth : Sign Up/In
Company -down-> CompanyUI : Post Jobs
Admin -down-> AdminUI : Manage Platform

' ============================================
' CONNECTIONS - FRONTEND TO BACKEND
' ============================================

Landing -down-> APIClient : API Calls
FrontendAuth -down-> APIClient
ApplicantUI -down-> APIClient
CompanyUI -down-> APIClient
AdminUI -down-> APIClient

APIClient -down-> StateManagement : Store Data
StateManagement -down-> APIClient : Retrieve Data

APIClient -[bold]down-> Router : HTTP Requests\n(REST API)\nJSON + JWT

' ============================================
' CONNECTIONS - SERVER-1 INTERNAL
' ============================================

Router -down-> Middleware : Request Pipeline
Middleware -down-> Controllers : Authorized Request

Controllers -down-> Services1 : Business Logic
Controllers -down-> Models : Database Operations

Services1 -down-> Models : Data Access
Models -[bold]down-> MongoDB : Mongoose ODM\n(CRUD Operations)

' ============================================
' CONNECTIONS - SERVER-1 TO EXTERNAL SERVICES
' ============================================

Services1 -[bold]right-> Gemini : HTTP Request\nContent Enhancement
Services1 -[bold]right-> Cloudinary : HTTP Request\nImage Upload/Fetch
Services1 -[bold]right-> NodeMailer : SMTP\nSend Emails

' ============================================
' CONNECTIONS - SERVER-1 TO SERVER-2 (MICROSERVICES)
' ============================================

Services1 -[bold]down-> FastAPI : HTTP POST/DELETE/PUT\n(Microservice Communication)\nJSON Payload

note right of Services1
  **AI Recommendation Service**
  Axios-based HTTP client
  Endpoints:
  - POST /api/jobs/ingest
  - PUT /api/jobs/update
  - DELETE /api/jobs/delete
  - POST /api/profiles/ingest
  - POST /api/recommendations/
end note

' ============================================
' CONNECTIONS - SERVER-2 INTERNAL
' ============================================

FastAPI -down-> AIRoutes : Route Request
AIRoutes -down-> AIServices : Service Layer

AIServices -down-> AIUtils : Helper Functions
AIServices -down-> AIConfig : Configuration

' ============================================
' CONNECTIONS - SERVER-2 TO AI SERVICES
' ============================================

AIUtils -[bold]right-> OpenAI : REST API\nGenerate Embeddings
AIServices -down-> Pinecone : SDK\nVector Operations\n(Upsert, Query, Delete)

note right of AIServices
  **Matching Engine Flow:**
  1. Get applicant vector from Pinecone
  2. Query similar job vectors
  3. Calculate cosine similarity (0-1)
  4. Enhance with skill matching
  5. Rank by combined score
  6. Return top N recommendations
end note

' ============================================
' DEPLOYMENT INFORMATION
' ============================================

note bottom of NextJS
  **Deployment:** Vercel
  **Build:** next build
  **Env:** .env.local
  Production: https://careerkonnekt.vercel.app
  Development: http://localhost:3000
end note

note bottom of Server1
  **Deployment:** Vercel/Railway
  **Runtime:** Node.js 18+
  **Package Manager:** npm
  **Env:** .env
  Production: https://career-konnekt-backend-server-1.vercel.app
  Development: http://localhost:4000
end note

note bottom of Server2
  **Deployment:** Railway/Render
  **Runtime:** Python 3.11+
  **Package Manager:** uv
  **Env:** .env
  Production: TBD
  Development: http://localhost:8000
end note

note bottom of MongoDB
  **Provider:** MongoDB Atlas (Cloud)
  **Region:** Nearest to users
  **Backup:** Automatic daily backups
  **Connection:** mongoose
end note

note bottom of Pinecone
  **Plan:** Serverless (Starter/Growth)
  **Index:** careerkonnekt-jobs
  **Dimensions:** 1536
  **Metric:** cosine similarity
  **Namespaces:** jobs, profiles
end note

' ============================================
' DATA FLOW ANNOTATIONS
' ============================================

note top of APIClient
  **Authentication Flow:**
  1. User login → JWT token
  2. Store in localStorage/cookies
  3. Attach to all API requests
  4. Refresh on expiry
end note

note top of MatchingEngine
  **AI Recommendation Algorithm:**
  
  1. Text Preparation
     - Combine job/profile attributes
     - Normalize and clean text
  
  2. Vector Generation (OpenAI)
     - Create 1536-dim embedding
     - Store in Pinecone with metadata
  
  3. Similarity Search
     - Query vector space
     - Cosine similarity scoring
     - Apply filters (location, type)
  
  4. Enhanced Matching
     - Parse required_skills
     - Match with applicant skills
     - Calculate skill_match_percentage
  
  5. Final Ranking
     - Sort by similarity score
     - Break ties with skill count
     - Return top-k results
end note

@enduml
```

---

# 🎨 Detailed Component Breakdown

## 1️⃣ Frontend Layer (Next.js)
**Technology:** React, Next.js 14, TailwindCSS  
**Port:** 3000/3001  
**Deployment:** Vercel

### Key Components:
- **Landing Pages:** Marketing, features, home
- **Authentication:** Sign up, sign in, email verification, password reset
- **Applicant Dashboard:** Profile, CV download, job recommendations, AI enhancement
- **Company Dashboard:** Job posting, applicant management, interview scheduling
- **Admin Panel:** User management, company verification, system monitoring

### State Management:
- Context API for global state
- Cookie Manager for session persistence
- Token Manager for JWT handling

---

## 2️⃣ Backend Layer - Server-1 (Node.js/Express)
**Technology:** Express.js, Mongoose, JWT  
**Port:** 4000  
**Deployment:** Vercel/Railway

### Architecture Layers:

#### **Routes Layer:**
- Auth routes (`/api/auth/*`)
- Applicant routes (`/api/applicant/*`)
- Company routes (`/api/company/*`)
- Admin routes (`/api/admin/*`)

#### **Middleware Layer:**
- JWT Authentication
- Role-based Authorization
- Profile Completion Check
- Input Validation
- Error Handling

#### **Controller Layer:**
- Auth Controllers (login, register, verify)
- Applicant Controllers (profile, CV, recommendations)
- Company Controllers (jobs, applications)
- Admin Controllers (verification, analytics)

#### **Service Layer:**
- **AI Recommendation Service:** HTTP client to Server-2
- **Email Service:** NodeMailer integration
- **PDF Generator:** CV templates with PDFKit
- **Cloudinary Service:** Image upload/retrieval
- **Gemini AI Service:** Content enhancement

#### **Model Layer (Mongoose ODM):**
- User Model (authentication)
- Applicant Model (user profile)
- Company Model (company profile)
- Profile Model (detailed resume)
- JobPost Model (job listings)
- Application Model (job applications)

---

## 3️⃣ Backend Layer - Server-2 (FastAPI/Python)
**Technology:** FastAPI, Pydantic, Pinecone SDK, OpenAI SDK  
**Port:** 8000  
**Deployment:** Railway/Render

### Architecture Layers:

#### **API Layer (FastAPI):**
- CORS middleware (allow Server-1 & Frontend)
- Health check endpoint (`/health`)
- Error handlers & logging

#### **Routes Layer:**
- **Job Routes:**
  - `POST /api/jobs/ingest` - Add job to vector DB
  - `PUT /api/jobs/update` - Update job vector
  - `DELETE /api/jobs/delete` - Remove job from vector DB

- **Profile Routes:**
  - `POST /api/profiles/ingest` - Add profile to vector DB
  - `DELETE /api/profiles/delete` - Remove profile

- **Recommendation Routes:**
  - `POST /api/recommendations/` - Get personalized job recommendations

#### **Service Layer:**
- **Job Service:** Job CRUD in Pinecone
- **Profile Service:** Profile CRUD in Pinecone
- **Matching Engine:**
  - Vector similarity search
  - Skill-based matching
  - Score calculation & ranking

#### **Utilities Layer:**
- **Embedding Generator:** OpenAI text-embedding-3-small
- **Text Preprocessor:** Clean and prepare text
- **Metadata Extractor:** Parse job/profile attributes

#### **Configuration Layer:**
- Pydantic Settings (env variables)
- Pinecone Manager (singleton connection)
- OpenAI Configuration

---

## 4️⃣ Data Layer

### MongoDB (Primary Database)
**Provider:** MongoDB Atlas  
**Connection:** Mongoose ODM

#### Collections:
1. **users** - Authentication data
   - email, password (hashed), role, is_verified
   
2. **applicants** - Applicant profiles
   - user_id, name, skills, experience, location
   
3. **companies** - Company profiles
   - user_id, company_name, industry, location
   
4. **profiles** - Detailed resumes
   - applicant_id, professional_summary, education, experience, projects
   
5. **jobposts** - Job listings
   - company_id, title, description, requirements, salary, status
   
6. **applications** - Job applications
   - job_id, applicant_id, cover_letter, status

### Pinecone (Vector Database)
**Provider:** Pinecone Serverless  
**Index:** careerkonnekt-jobs  
**Dimensions:** 1536  
**Metric:** Cosine Similarity

#### Namespaces:
1. **jobs** - Job vectors
   - Vector ID: `job_{mongodb_id}`
   - Embedding: 1536-dimensional array
   - Metadata: title, company, location, skills, description
   
2. **profiles** - Profile vectors
   - Vector ID: `profile_{applicant_id}`
   - Embedding: 1536-dimensional array
   - Metadata: name, skills, experience, location, current_role

---

## 5️⃣ External Services Layer

### OpenAI API
- **Model:** text-embedding-3-small
- **Purpose:** Generate semantic embeddings
- **Input:** Job/Profile text (combined attributes)
- **Output:** 1536-dimensional vector
- **Planned:** GPT-4 for AI interviews

### Google Gemini AI
- **Purpose:** Content enhancement
- **Use Cases:**
  - Professional summary improvement
  - Experience description enhancement
  - Project description refinement

### Cloudinary
- **Purpose:** Media storage
- **Use Cases:**
  - Profile pictures
  - Company logos
  - Document uploads

### NodeMailer (SMTP)
- **Purpose:** Email notifications
- **Use Cases:**
  - OTP verification
  - Password reset
  - Application status updates
  - Interview invitations

---

# 🔄 Key Data Flows

## Flow 1: User Registration & Verification
```
User → Frontend → Server-1 → MongoDB (create user)
                → NodeMailer (send OTP)
User enters OTP → Frontend → Server-1 → MongoDB (verify)
```

## Flow 2: Profile Creation with AI Sync
```
Applicant → Frontend → Server-1 → MongoDB (save profile)
                                → Server-2 → OpenAI (generate embedding)
                                          → Pinecone (store vector)
```

## Flow 3: Job Posting with AI Vectorization
```
Company → Frontend → Server-1 → MongoDB (save job)
                              → Server-2 → OpenAI (generate embedding)
                                        → Pinecone (store vector)
```

## Flow 4: AI-Powered Job Recommendations
```
Applicant → Frontend → Server-1 → Server-2 → Pinecone (fetch profile vector)
                                           → Pinecone (query similar jobs)
                                           → MatchingEngine (score & rank)
                                 → Server-1 → Frontend (display ranked jobs)
```

## Flow 5: CV Generation
```
Applicant → Frontend → Server-1 → MongoDB (fetch profile)
                                → PDF Generator (create CV)
                                → Frontend (download PDF)
```

## Flow 6: AI Content Enhancement
```
Applicant → Frontend → Server-1 → Gemini AI (enhance text)
                                → Frontend (display enhanced content)
```

---

# 🔐 Security Architecture

## Authentication & Authorization:
- **JWT Tokens:** 7-day expiry (users), 8-hour expiry (admin)
- **Password Hashing:** bcrypt with salt rounds
- **Email Verification:** OTP-based (10-minute expiry)
- **Role-Based Access Control:** Applicant, Company, Admin roles

## Data Protection:
- **HTTPS:** All production traffic encrypted
- **Environment Variables:** Sensitive credentials in .env
- **CORS:** Whitelist specific origins
- **Input Validation:** Server-side validation on all endpoints

## API Security:
- **Rate Limiting:** Prevent abuse (planned)
- **JWT Middleware:** All protected routes require valid token
- **Ownership Checks:** Users can only access their own data

---

# 🚀 Deployment Architecture

## Frontend (Vercel)
- **Build Command:** `npm run build`
- **Deploy Command:** Automatic on git push
- **Environment:** Production variables in Vercel dashboard
- **CDN:** Global edge network

## Server-1 (Vercel/Railway)
- **Build:** Automatic with package.json
- **Port:** 4000 (configurable)
- **Environment:** .env variables
- **Health Check:** `/health` endpoint

## Server-2 (Railway/Render)
- **Build:** `uv sync` (Python dependencies)
- **Start:** `python startup.py`
- **Port:** 8000
- **Environment:** .env variables
- **Health Check:** `/health` endpoint

## Databases
- **MongoDB Atlas:** Cloud-hosted, automatic backups
- **Pinecone Serverless:** Cloud-hosted, auto-scaling

---

# 📊 System Characteristics

## Scalability:
- **Horizontal:** Microservices can scale independently
- **Vertical:** Serverless databases auto-scale
- **Load Balancing:** Handled by deployment platforms

## Performance:
- **Response Time:** < 500ms for most API calls
- **Recommendation Generation:** < 2 seconds
- **Vector Search:** < 200ms (Pinecone optimized)

## Reliability:
- **Error Handling:** Graceful degradation (AI service fails → job still posted)
- **Database Backups:** Daily automatic backups
- **Monitoring:** Health checks on all services

## Maintainability:
- **Separation of Concerns:** Clear layer separation
- **Microservices:** Independent deployment & updates
- **Code Organization:** MVC pattern in Server-1, clean architecture in Server-2

---

# 🎓 Architecture Patterns Used

1. **Microservices Architecture:** Server-1 (business logic) + Server-2 (AI service)
2. **MVC Pattern:** Model-View-Controller in Server-1
3. **RESTful API:** Standard HTTP methods & status codes
4. **Service-Oriented Architecture (SOA):** External service integrations
5. **Event-Driven (Planned):** Real-time notifications via WebSockets
6. **Layered Architecture:** Presentation → Business → Data layers

---

# 📝 Rendering Instructions

## Online PlantUML Editor (Recommended)
1. Visit: https://www.plantuml.com/plantuml/uml/
2. Copy the entire PlantUML code above
3. Paste into the editor
4. View rendered architecture
5. Export as PNG/SVG (high resolution)

## VS Code Extension
1. Install "PlantUML" extension
2. Install Graphviz: https://graphviz.org/download/
3. Save code as `architecture.puml`
4. Press `Alt+D` to preview
5. Right-click → Export

## Tips for Best Rendering:
- Use **high DPI export** for presentations
- Choose **SVG format** for scalability
- Adjust colors in skinparam for your theme
- Use landscape orientation for printing

---

# 🎯 For Your FYP Presentation

## Key Highlights to Explain:

1. **Microservices Architecture:** 
   - Separate AI service from main backend
   - Independent scaling & deployment
   - Technology flexibility (Node.js + Python)

2. **AI Integration:**
   - Vector embeddings for semantic search
   - Cosine similarity matching
   - Enhanced with skill-based scoring

3. **Scalability:**
   - Serverless databases
   - Horizontal scaling capability
   - Cloud-native deployment

4. **Security:**
   - JWT authentication
   - Role-based access control
   - Email verification

5. **External Integrations:**
   - OpenAI for embeddings
   - Gemini for content enhancement
   - Cloudinary for media
   - NodeMailer for notifications

## Presentation Flow:
1. Start with high-level overview (actors → frontend → backend → data)
2. Zoom into microservices communication (Server-1 ↔ Server-2)
3. Explain AI recommendation flow in detail
4. Highlight deployment strategy
5. Discuss security measures

---

# ✅ Summary

This architecture diagram demonstrates:
- ✅ **Complete system overview** with all components
- ✅ **Microservices architecture** with clear separation
- ✅ **AI/ML integration** with vector databases
- ✅ **Professional design** suitable for FYP evaluation
- ✅ **Detailed annotations** explaining each component
- ✅ **Data flow documentation** showing system interactions
- ✅ **Deployment strategy** with platform specifications

**Perfect for academic presentations and technical documentation!** 🚀🎓
